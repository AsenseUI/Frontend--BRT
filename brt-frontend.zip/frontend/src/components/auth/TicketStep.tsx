// components/auth/TicketStep.tsx

import React, { useState, useEffect } from "react";
import { Check, X, Download, FileText, Eye, Loader2, Wallet } from "lucide-react";
import { Link } from "react-router-dom";
import jsPDF from "jspdf";
import QRCode from "qrcode";
import { generateTicketPDF, TicketPDFData } from "./ticketPDFService";

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

interface TicketStepProps {
  formData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
  };
  selectedPlan: "full" | "partial" | null;
  transactionId?: string;
  ticketData?: {
    _id: string;
    ticketId: string;
    generatedTicketNumber?: string | null;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    selectedPlan: string;
    paymentMethod: string;
    paymentStatus: string;
    amountPaid: number;
    totalAmount: number;
    outstandingBalance: number;
    transactionId: string;
    eventName: string;
    eventDate: string;
    status: string;
    isDownloaded?: boolean;
    downloadCount?: number;
  };
  onClose?: () => void;
  onViewTicket?: () => void;
  onDownloadReceipt?: () => void;
}

const TicketStep: React.FC<TicketStepProps> = ({
  formData,
  selectedPlan,
  transactionId = "TXN-BRT-2026-7712A",
  ticketData,
  onClose,
  onViewTicket,
  onDownloadReceipt
}) => {
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatingType, setGeneratingType] = useState<'view' | 'download' | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string | null>(null);
  const [isAddingToWallet, setIsAddingToWallet] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(ticketData?.isDownloaded || false);
  const [downloadCount, setDownloadCount] = useState(ticketData?.downloadCount || 0);

  const fullName = `${formData.firstName} ${formData.lastName}`.trim() || 'Attendee';

  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('en-ZA', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const amountPaid = ticketData?.amountPaid
    ? `R${ticketData.amountPaid.toLocaleString('en-ZA')}`
    : selectedPlan === 'full'
      ? 'R2,040'
      : 'R1,018';

  const displayTransactionId = ticketData?.transactionId || transactionId;
  const displayTicketId = ticketData?.generatedTicketNumber || ticketData?.ticketId || "BRT-2026-XXXX";
  const originalTicketId = ticketData?.ticketId || "BRT-2026-XXXX";
  const displayEventName = "BRT 150 - Black Carpet Gala";
  const displayEventDate = ticketData?.eventDate
    ? new Date(ticketData.eventDate).toLocaleDateString('en-ZA', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    })
    : "21 November 2026";
  const displayStatus = ticketData?.status || "confirmed";
  const hasGeneratedTicket = !!ticketData?.generatedTicketNumber;

  // QR code URL - points to verification page
  const ticketScanUrl = `${window.location.origin}/verifyticket?ticketId=${displayTicketId}`;

  useEffect(() => {
    QRCode.toDataURL(ticketScanUrl, {
      width: 300,
      margin: 1,
      color: {
        dark: "#050505",
        light: "#FFFFFF",
      },
    })
      .then(setQrCodeDataUrl)
      .catch((err) => console.error("Failed to generate ticket QR code:", err));
  }, [displayTicketId]);

  const handleClose = () => {
    if (onClose) onClose();
  };

  // ✅ Track download on backend
  const trackTicketDownload = async () => {
    if (!ticketData?._id) return;

    try {
      const response = await fetch(`${API_BASE_URL}/api/tickets/${ticketData._id}/track-download`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          ticketId: ticketData.ticketId,
          generatedTicketNumber: ticketData.generatedTicketNumber || null
        }),
      });

      const result = await response.json();

      if (!response.ok) {
        if (result.alreadyDownloaded) {
          alert('This ticket has already been downloaded. You can only download it once.');
          return false;
        }
        throw new Error(result.message || 'Failed to track download');
      }

      if (result.success) {
        setIsDownloaded(true);
        setDownloadCount(result.data.downloadCount || downloadCount + 1);
        console.log(`✅ Ticket download tracked. Count: ${result.data.downloadCount}`);
        return true;
      }

      return false;
    } catch (error) {
      console.error('Failed to track ticket download:', error);
      alert('Failed to track download. Please try again.');
      return false;
    }
  };

  // ✅ Updated to use new ticketPDFService
  const handleViewTicket = async () => {
    if (onViewTicket) {
      onViewTicket();
    } else {
      setGeneratingType('view');
      setIsGenerating(true);
      try {
        // ✅ Build ticket data for PDF
        const ticketPDFData: TicketPDFData = {
          ticketId: displayTicketId,
          eventName: displayEventName,
          date: displayEventDate,
          time: '16:00HRS',
          venue: 'Ethereal, Newcastle, KZN.',
          gate: '1',
          web: 'www.thebrtsa.com',
          firstName: formData.firstName,
          lastName: formData.lastName,
        };

        await generateTicketPDF('view', ticketPDFData);
      } catch (error) {
        console.error('Error viewing ticket:', error);
        alert('Failed to generate ticket. Please try again.');
      } finally {
        setIsGenerating(false);
        setGeneratingType(null);
      }
    }
  };

  // ✅ Updated to use new ticketPDFService
  const handleDownloadTicket = async () => {
    if (isDownloaded) {
      alert('This ticket has already been downloaded. You can only download it once.');
      return;
    }

    setGeneratingType('download');
    setIsGenerating(true);
    try {
      const canDownload = await trackTicketDownload();

      if (!canDownload) {
        setIsGenerating(false);
        setGeneratingType(null);
        return;
      }

      // ✅ Build ticket data for PDF
      const ticketPDFData: TicketPDFData = {
        ticketId: displayTicketId,
        eventName: displayEventName,
        date: displayEventDate,
        time: '16:00HRS',
        venue: 'Ethereal, Newcastle, KZN.',
        gate: '1',
        web: 'www.thebrtsa.com',
        firstName: formData.firstName,
        lastName: formData.lastName,
      };

      await generateTicketPDF('download', ticketPDFData);

      console.log('✅ Ticket downloaded successfully (one-time download)');
    } catch (error) {
      console.error('Error downloading ticket:', error);
      alert('Failed to download ticket. Please try again.');
    } finally {
      setIsGenerating(false);
      setGeneratingType(null);
    }
  };

  // ✅ Add to Apple Wallet
  const handleAddToWallet = async () => {
    if (!ticketData?.ticketId) {
      alert('No ticket ID found');
      return;
    }

    setIsAddingToWallet(true);
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/wallet/passes/${ticketData.ticketId}`,
        {
          method: 'GET',
          headers: {
            'Authorization': `Bearer ${localStorage.getItem('accessToken') || ''}`,
          },
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to generate wallet pass');
      }

      const blob = await response.blob();
      const contentType = response.headers.get('content-type') || '';

      if (!contentType.includes('pkpass') && !contentType.includes('zip')) {
        const text = await blob.text();
        console.error('Unexpected response:', text);
        throw new Error('Invalid response from server');
      }

      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `ticket-${ticketData.ticketId}.pkpass`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      setTimeout(() => {
        window.URL.revokeObjectURL(url);
      }, 1000);

      console.log('✅ Wallet pass downloaded successfully');

    } catch (error) {
      console.error('Error adding to Apple Wallet:', error);
      alert(error instanceof Error ? error.message : 'Failed to add to Apple Wallet. Please try again.');
    } finally {
      setIsAddingToWallet(false);
    }
  };

  // ✅ Generate Receipt PDF (kept inline)
  const generateReceiptPDF = () => {
    const pdf = new jsPDF('p', 'mm', 'a4');
    const pageWidth = pdf.internal.pageSize.getWidth();

    pdf.setFillColor(5, 5, 5);
    pdf.rect(0, 0, pageWidth, 210, 'F');

    pdf.setDrawColor(201, 162, 39);
    pdf.setLineWidth(0.5);
    pdf.roundedRect(10, 10, pageWidth - 20, 190, 5, 5, 'S');

    pdf.setFontSize(10);
    pdf.setTextColor(201, 162, 39);
    pdf.text('BRT 150 - Black Carpet Gala', pageWidth / 2, 30, { align: 'center' });

    pdf.setFontSize(22);
    pdf.setTextColor(255, 255, 255);
    pdf.text('PAYMENT RECEIPT', pageWidth / 2, 45, { align: 'center' });

    pdf.setDrawColor(201, 162, 39);
    pdf.line(40, 55, pageWidth - 40, 55);

    pdf.setFontSize(11);
    let yPos = 75;
    const lineHeight = 12;

    const details: [string, string][] = [
      ['Receipt ID', displayTicketId],
    ];

    if (hasGeneratedTicket) {
      details.push(['Original ID', originalTicketId]);
    }

    details.push(
      ['Transaction ID', displayTransactionId],
      ['Amount Paid', amountPaid],
      ['Date', formattedDate],
      ['Payment Status', 'COMPLETED'],
      ['Attendee', fullName],
      ['Email', formData.email],
      ['Phone', formData.phone]
    );

    details.forEach(([label, value]) => {
      pdf.setFont('helvetica', 'bold');
      pdf.setTextColor(128, 128, 128);
      pdf.setFontSize(10);
      pdf.text(label + ':', 30, yPos);

      pdf.setFont('helvetica', 'normal');
      pdf.setTextColor(255, 255, 255);
      pdf.setFontSize(11);

      const maxWidth = pageWidth - 80;
      const lines = pdf.splitTextToSize(value, maxWidth);
      pdf.text(lines, 90, yPos);

      yPos += lineHeight * (lines.length > 1 ? lines.length : 1);
    });

    const footerY = 190;
    pdf.setFontSize(9);
    pdf.setTextColor(128, 128, 128);
    pdf.text('Thank you for your payment. This receipt is for your records.', pageWidth / 2, footerY, { align: 'center' });

    pdf.save(`receipt-${displayTicketId}.pdf`);
  };

  const handleDownloadReceipt = () => {
    if (onDownloadReceipt) {
      onDownloadReceipt();
    } else {
      try {
        generateReceiptPDF();
      } catch (error) {
        console.error('Error downloading receipt:', error);
      }
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center px-4 py-4"
      style={{
        background: "rgba(5, 5, 5, 0.85)",
        backdropFilter: "blur(14px)",
      }}
      onClick={handleClose}
    >
      <div
        className="relative w-full max-w-[480px] max-h-[90vh] overflow-y-auto rounded-2xl p-8 text-center"
        style={{
          background: "linear-gradient(160deg, rgb(28, 18, 8) 0%, rgb(17, 13, 5) 50%, rgb(14, 9, 9) 100%)",
          border: "1px solid rgb(201, 162, 39)",
          boxShadow: "rgba(201, 162, 39, 0.22) 0px 0px 80px, rgba(0, 0, 0, 0.7) 0px 40px 100px",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <Link
          to="/"
          onClick={handleClose}
          className="absolute top-4 right-4 transition-colors text-white/22 hover:text-white/60 z-10"
        >
          <X className="w-[18px] h-[18px]" />
        </Link>

        {/* Success Icon */}
        <div className="flex justify-center mb-4">
          <div
            className="w-16 h-16 rounded-full flex items-center justify-center"
            style={{
              background: "linear-gradient(135deg, rgb(201, 162, 39), rgb(223, 186, 58))",
              boxShadow: "rgba(201, 162, 39, 0.45) 0px 0px 60px",
            }}
          >
            <Check className="w-[28px] h-[28px] stroke-[2.5] text-[#050505]" />
          </div>
        </div>

        {/* Title */}
        <div className="text-[10px] font-bold uppercase tracking-[0.25em] mb-1 text-[#C9A227]">
          Payment Confirmed
        </div>
        <h2 className="text-white font-bold text-xl mb-1">
          Your Spot Is Reserved
        </h2>
        <p className="text-xs font-medium leading-relaxed mb-4 max-w-xs mx-auto text-white/42">
          Welcome to {displayEventName}. Your ticket has been confirmed and your seat is secured.
        </p>

        {/* Ticket ID Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4 bg-[#C9A227]/10 border border-[#C9A227]/20">
          <FileText className="w-3 h-3 text-[#C9A227]" />
          <span className="text-[10px] font-bold uppercase tracking-wider text-[#C9A227]">
            Ticket #{displayTicketId}
          </span>
          {hasGeneratedTicket && (
            <span className="text-[8px] text-white/30 ml-1">
              (was: {originalTicketId})
            </span>
          )}
        </div>

        {/* QR Code */}
        <div className="flex flex-col items-center gap-1 mb-4">
          <div className="p-2 rounded-xl bg-white">
            {qrCodeDataUrl ? (
              <img
                src={qrCodeDataUrl}
                alt={`QR code for ticket ${displayTicketId}`}
                className="w-24 h-24 sm:w-28 sm:h-28"
              />
            ) : (
              <div className="w-24 h-24 flex items-center justify-center">
                <Loader2 className="w-4 h-4 animate-spin text-[#050505]/40" />
              </div>
            )}
          </div>
          <span className="text-[10px] font-bold uppercase tracking-wider text-white/30">
            Scan to verify ticket
          </span>
        </div>

        {/* Details */}
        <div
          className="text-left rounded-xl p-3 mb-4 space-y-1.5"
          style={{
            background: "rgba(0, 0, 0, 0.3)",
            border: "1px solid rgba(201, 162, 39, 0.12)",
          }}
        >
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-medium text-white/35">Ticket ID</span>
            <span className="text-[11px] font-bold text-[#C9A227]">{displayTicketId}</span>
          </div>
          {hasGeneratedTicket && (
            <div className="flex justify-between items-center">
              <span className="text-[11px] font-medium text-white/35">Original ID</span>
              <span className="text-[11px] font-bold text-white/50">{originalTicketId}</span>
            </div>
          )}
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-medium text-white/35">Amount Paid</span>
            <span className="text-[11px] font-bold text-[#C9A227]">{amountPaid}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-medium text-white/35">Transaction ID</span>
            <span className="text-[11px] font-bold text-white/70">{displayTransactionId}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-medium text-white/35">Event Date</span>
            <span className="text-[11px] font-bold text-white/70">{displayEventDate}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-[11px] font-medium text-white/35">Attendee</span>
            <span className="text-[11px] font-bold text-white/70">{fullName}</span>
          </div>
          <div className="flex justify-between items-center pt-1.5" style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}>
            <span className="text-[11px] font-medium text-white/35">Status</span>
            <span className="text-[11px] font-bold text-[#22C55E]">
              {displayStatus === 'confirmed' || displayStatus === 'approved' ? '✓ Confirmed' : displayStatus.charAt(0).toUpperCase() + displayStatus.slice(1)}
            </span>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex flex-col gap-2.5">
          {/* View Ticket Button */}
          <button
            onClick={handleViewTicket}
            disabled={isGenerating}
            className="inline-flex items-center justify-center gap-2 font-bold rounded-xl transition-all duration-200 active:scale-[0.99] w-full px-8 py-3 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: "linear-gradient(135deg, rgb(201, 162, 39) 0%, rgb(223, 186, 58) 100%)",
              color: "rgb(5, 5, 5)",
              boxShadow: "rgba(201, 162, 39, 0.25) 0px 4px 24px",
            }}
          >
            {isGenerating && generatingType === 'view' ? (
              <>
                <Loader2 className="w-3.5 h-3.5 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Eye className="w-3.5 h-3.5" />
                View Ticket
              </>
            )}
          </button>

          {/* Download Ticket Button */}
          <button
            onClick={handleDownloadTicket}
            disabled={isGenerating || isDownloaded}
            className={`inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all duration-200 active:scale-[0.99] w-full px-8 py-2.5 text-xs disabled:opacity-50 disabled:cursor-not-allowed ${
              isDownloaded
                ? 'border border-green-500/30 text-green-400 bg-green-500/10 cursor-not-allowed'
                : 'border border-white/10 text-white/55 bg-transparent hover:bg-white/5'
            }`}
          >
            {isGenerating && generatingType === 'download' ? (
              <>
                <Loader2 className="w-3 h-3 animate-spin" />
                Downloading...
              </>
            ) : isDownloaded ? (
              <>
                <Check className="w-3 h-3" />
                Already Downloaded ✓
              </>
            ) : (
              <>
                <Download className="w-3 h-3" />
                Download Ticket
              </>
            )}
          </button>

          {/* Add to Apple Wallet */}
          <button
            onClick={handleAddToWallet}
            disabled={isAddingToWallet}
            className="inline-flex items-center justify-center gap-2 font-semibold rounded-xl transition-all duration-200 active:scale-[0.99] w-full px-8 py-2.5 text-xs disabled:opacity-50 disabled:cursor-not-allowed"
            style={{
              background: "linear-gradient(135deg, #000000 0%, #1a1a1a 100%)",
              border: "1px solid rgba(255, 255, 255, 0.15)",
              color: "white",
            }}
          >
            {isAddingToWallet ? (
              <>
                <Loader2 className="w-3 h-3 animate-spin" />
                Generating Pass...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <rect x="2" y="4" width="20" height="16" rx="2" />
                  <path d="M8 2v4M16 2v4M2 10h20" />
                </svg>
                Add to Apple Wallet
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default TicketStep;