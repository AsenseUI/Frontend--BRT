// services/ticketPDFService.ts
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import QRCode from 'qrcode';
import { Partner, getSortedPartners } from '@/config/partners';

export interface TicketPDFData {
  ticketId: string;
  eventName?: string;
  date?: string;
  time?: string;
  venue?: string;
  gate?: string;
  web?: string;
  firstName?: string;
  lastName?: string;
  partners?: Partner[];
}

/**
 * Generate QR Code as Data URL
 */
export const generateQRCodeDataUrl = async (value: string): Promise<string> => {
  try {
    const canvas = document.createElement('canvas');
    await QRCode.toCanvas(canvas, value, {
      width: 300,
      height: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'H',
    });
    return canvas.toDataURL('image/png');
  } catch (error) {
    console.error('QR Code generation failed:', error);
    throw error;
  }
};

/**
 * Convert image URL to base64 with better error handling
 */
const imageUrlToBase64 = (url: string): Promise<string> => {
  return new Promise((resolve, reject) => {
    // If URL is empty or already base64, return it
    if (!url) {
      resolve('');
      return;
    }
    if (url.startsWith('data:image')) {
      resolve(url);
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    // Set timeout for image loading
    const timeoutId = setTimeout(() => {
      reject(new Error(`Image load timeout: ${url}`));
    }, 10000);

    img.onload = () => {
      clearTimeout(timeoutId);
      try {
        const canvas = document.createElement('canvas');
        canvas.width = img.width;
        canvas.height = img.height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          reject(new Error('Could not get canvas context'));
          return;
        }
        ctx.drawImage(img, 0, 0);
        resolve(canvas.toDataURL('image/png'));
      } catch (error) {
        reject(error);
      }
    };
    img.onerror = () => {
      clearTimeout(timeoutId);
      reject(new Error(`Failed to load image: ${url}`));
    };
    img.src = url;
  });
};

/**
 * Create ticket HTML element with logos
 */
const createTicketElement = async (
  ticketData: TicketPDFData,
  qrCodeDataUrl: string
): Promise<HTMLElement> => {
  const container = document.createElement('div');
  container.style.position = 'absolute';
  container.style.left = '-9999px';
  container.style.top = '-9999px';
  container.style.width = '423px';
  container.style.background = '#0a0806';
  container.style.borderRadius = '18px';
  container.style.overflow = 'hidden';
  container.style.fontFamily = '"Helvetica Neue", Arial, sans-serif';
  document.body.appendChild(container);

  const {
    ticketId,
    eventName = 'THE BLACK CARPET GALA',
    date = 'November 21, 2026',
    time = '16:00HRS',
    venue = 'Ethereal, Newcastle, KZN.',
    gate = '1',
    web = 'www.thebrtsa.com',
    firstName,
    lastName,
  } = ticketData;

  const displayName = firstName && lastName ? `${firstName} ${lastName}` : '';
  
  // Use provided partners or get sorted default partners
  const partners = ticketData.partners || getSortedPartners();

  // Generate partners HTML with logos
  let partnersHTML = '';
  
  for (const partner of partners) {
    let logoHTML = '';
    const isMore = partner.name === 'More Partners' || partner.name === 'Sponsors';
    
    if (partner.logoUrl) {
      try {
        const base64Logo = await imageUrlToBase64(partner.logoUrl);
        if (base64Logo) {
          // Different sizing for Audi Centre to accommodate longer text
          const logoStyle = partner.name.includes('Audi') 
            ? 'max-width:70px;max-height:35px;'
            : 'max-width:60px;max-height:40px;';
          
          logoHTML = `
            <img 
              src="${base64Logo}" 
              alt="${partner.name}" 
              style="${logoStyle}object-fit:contain;margin-bottom:2px;" 
            />
          `;
        }
      } catch (error) {
        console.warn(`Failed to load logo for ${partner.name}:`, error);
        logoHTML = '';
      }
    }

    // Special handling for Audi Centre to show "Audi Centre Newcastle" text below
    const displayName = partner.name.includes('Audi') 
      ? 'Audi Centre Newcastle'
      : partner.name;

    partnersHTML += `
      <div style="
        border:1px solid rgba(201,162,39,0.18);
        padding:10px 6px;
        display:flex;
        flex-direction:column;
        align-items:center;
        justify-content:center;
        min-height:70px;
        text-align:center;
        ${isMore ? 'opacity:0.4;' : ''}
      ">
        ${logoHTML}
        <div style="
          color:#DFBA3A;
          font-size:${partner.name.includes('Audi') ? '7px' : '8px'};
          font-weight:700;
          letter-spacing:0.3px;
          line-height:1.2;
          text-transform:uppercase;
          margin-top:${logoHTML ? '2px' : '0'};
        ">
          ${displayName}
        </div>
        // <div style="
        //   color:rgba(230,215,180,0.4);
        //   font-size:6px;
        //   margin-top:1px;
        //   letter-spacing:0.3px;
        // ">
        //   ${partner.label}
        // </div>
      </div>
    `;
  }

  // Generate barcode-like visual
  const barcodeHTML = ticketId.split('').map(char => 
    `<span style="display:inline-block;width:8px;height:24px;background:#000;margin:0 1px;${['-',' '].includes(char) ? 'opacity:0.3;' : ''}"></span>`
  ).join('');

  container.innerHTML = `
    <div style="width:423px;background:#0a0806;border-radius:18px;overflow:hidden;font-family:'Helvetica Neue',Arial,sans-serif;">
      <!-- Header -->
      <div style="background:radial-gradient(ellipse 120% 80% at 50% 0%, rgba(212,175,55,0.55) 0%, rgba(212,175,55,0.25) 25%, rgba(20,16,10,0.95) 55%, #0d0b08 100%), linear-gradient(180deg, #1a1408 0%, #0a0806 100%);background-color:#0a0806;padding:34px 28px 18px;min-height:200px;">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:22px;">
          <div style="color:#fff;font-size:22px;font-weight:800;letter-spacing:0.5px;">THE BRT150</div>
          <div style="text-align:right;">
            <div style="color:#DFBA3A;font-size:10px;font-weight:700;letter-spacing:1.5px;">EVENT NAME</div>
            <div style="color:rgba(230,215,180,0.85);font-size:13px;margin-top:2px;">${eventName}</div>
          </div>
        </div>
        
        <div style="margin-bottom:16px;">
          <div style="color:#C9A227;font-size:10px;font-weight:700;letter-spacing:1.5px;margin-bottom:4px;">DATE &amp; TIME</div>
          <div style="color:rgba(230,215,180,0.85);font-size:17px;font-weight:500;">${date}, ${time}</div>
        </div>
        
        <div style="margin-bottom:16px;">
          <div style="color:#C9A227;font-size:10px;font-weight:700;letter-spacing:1.5px;margin-bottom:4px;">VENUE</div>
          <div style="color:rgba(230,215,180,0.85);font-size:15px;font-weight:500;">${venue}</div>
        </div>
        
        <div style="display:flex;justify-content:space-between;align-items:flex-end;">
          <div>
            <div style="color:#C9A227;font-size:10px;font-weight:700;letter-spacing:1.5px;margin-bottom:4px;">WEB</div>
            <div style="color:rgba(230,215,180,0.85);font-size:15px;font-weight:500;">${web}</div>
          </div>
          <div style="text-align:right;flex-shrink:0;margin-left:12px;">
            <div style="color:#DFBA3A;font-size:10px;font-weight:700;letter-spacing:1px;">TICKET:</div>
            <div style="color:#fff;font-size:11px;font-weight:500;margin:1px 0 3px;">${ticketId}</div>
            <div style="color:#DFBA3A;font-size:10px;font-weight:700;letter-spacing:1px;">GATE: ${gate}</div>
          </div>
        </div>
      </div>
      
      <!-- Partners Section -->
      <div style="display:flex;align-items:center;gap:10px;margin:8px 28px 12px;">
        <hr style="flex:1;border:none;border-top:1px solid rgba(201,162,39,0.35);" />
        <span style="color:#C9A227;font-size:10px;font-weight:700;letter-spacing:2px;white-space:nowrap;">◆&nbsp; OFFICIAL PARTNERS &nbsp;◆</span>
        <hr style="flex:1;border:none;border-top:1px solid rgba(201,162,39,0.35);" />
      </div>
      
      <!-- Partners Grid - 2 columns -->
      <div style="display:grid;grid-template-columns:1fr 1fr;background:#0a0806;padding:0 4px;">
        ${partnersHTML}
      </div>
      
      <!-- Footer Divider -->
      <div style="margin:12px 28px 0;border-top:1px solid rgba(201,162,39,0.35);position:relative;">
        <div style="position:absolute;left:50%;top:-4px;transform:translateX(-50%);width:8px;height:8px;border-radius:50%;background:#DFBA3A;box-shadow:0 0 8px #DFBA3A;"></div>
      </div>
      
      <!-- QR Code & Barcode Section -->
      <div style="margin:16px 28px 24px;background:#fff;border-radius:6px;padding:14px 10px 12px;text-align:center;">
        ${qrCodeDataUrl ? `<img src="${qrCodeDataUrl}" alt="QR Code" style="width:75px;height:75px;margin:0 auto 6px;display:block;" />` : ''}
        <div style="font-weight:700;font-size:13px;letter-spacing:2px;color:#111;margin-top:2px;">${ticketId}</div>
        ${displayName ? `<div style="font-size:9px;color:#555;margin-top:1px;letter-spacing:0.3px;">${displayName}</div>` : ''}

      </div>
    </div>
  `;

  return container;
};

/**
 * Generate Ticket PDF
 */
export const generateTicketPDF = async (
  type: 'view' | 'download' | 'print',
  ticketData: TicketPDFData
): Promise<void> => {
  try {
    const ticketScanUrl = `${window.location.origin}/verifyticket?ticketId=${ticketData.ticketId}`;
    const qrCodeDataUrl = await generateQRCodeDataUrl(ticketScanUrl);

    const ticketElement = await createTicketElement(ticketData, qrCodeDataUrl);
    await new Promise(resolve => setTimeout(resolve, 300));

    const canvas = await html2canvas(ticketElement, {
      scale: 3,
      useCORS: true,
      logging: false,
      backgroundColor: '#0a0806',
      width: 423,
      height: ticketElement.scrollHeight,
      allowTaint: true,
      onclone: (document) => {
        const images = document.querySelectorAll('img');
        return Promise.all(Array.from(images).map(img => {
          if (img.complete && img.naturalWidth > 0) return Promise.resolve();
          return new Promise((resolve) => {
            img.onload = () => resolve();
            img.onerror = () => resolve();
            // Force reload if not loaded
            if (!img.complete) {
              const src = img.src;
              img.src = '';
              img.src = src;
            }
          });
        }));
      },
    });

    if (ticketElement.parentNode) {
      document.body.removeChild(ticketElement);
    }

    const pdfWidth = 100;
    const pdfHeight = 100 * (canvas.height / canvas.width);
    
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [pdfWidth, pdfHeight],
    });

    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);

    const fileName = `ticket-${ticketData.ticketId}.pdf`;

    if (type === 'view') {
      const pdfBlob = pdf.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      window.open(url, '_blank');
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } else if (type === 'print') {
      const pdfBlob = pdf.output('blob');
      const url = URL.createObjectURL(pdfBlob);
      const printWindow = window.open(url, '_blank');
      if (printWindow) {
        printWindow.onload = () => {
          setTimeout(() => printWindow.print(), 500);
        };
      }
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } else {
      pdf.save(fileName);
    }

  } catch (error) {
    console.error('PDF Generation error:', error);
    throw error;
  }
};

/**
 * Generate Ticket PDF and return as Blob
 */
export const generateTicketPDFAsBlob = async (
  ticketData: TicketPDFData
): Promise<Blob> => {
  try {
    const ticketScanUrl = `${window.location.origin}/verifyticket?ticketId=${ticketData.ticketId}`;
    const qrCodeDataUrl = await generateQRCodeDataUrl(ticketScanUrl);

    const ticketElement = await createTicketElement(ticketData, qrCodeDataUrl);
    await new Promise(resolve => setTimeout(resolve, 300));

    const canvas = await html2canvas(ticketElement, {
      scale: 3,
      useCORS: true,
      logging: false,
      backgroundColor: '#0a0806',
      width: 423,
      height: ticketElement.scrollHeight,
      allowTaint: true,
    });

    if (ticketElement.parentNode) {
      document.body.removeChild(ticketElement);
    }

    const pdfWidth = 100;
    const pdfHeight = 100 * (canvas.height / canvas.width);
    
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: [pdfWidth, pdfHeight],
    });

    const imgData = canvas.toDataURL('image/png');
    pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);

    return pdf.output('blob');

  } catch (error) {
    console.error('PDF Generation error:', error);
    throw error;
  }
};