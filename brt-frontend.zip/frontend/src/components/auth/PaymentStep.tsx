// components/auth/PaymentStep.tsx
import React from "react";
import { CreditCard, Smartphone, Building, Lock, Shield, Check, CircleCheckBig, Crown, Apple, Wallet } from "lucide-react";
import { Link } from "react-router-dom";

interface PaymentStepProps {
  selectedPlan: "full" | "partial" | null;
  paymentMethod: string | null;
  setPaymentMethod: (method: string) => void;
  acceptedTerms: boolean;
  setAcceptedTerms: (accepted: boolean) => void;
  error?: string | null;
  loading?: boolean;
  onPay?: () => void;
  onBack?: () => void;
}

const PaymentStep: React.FC<PaymentStepProps> = ({
  selectedPlan,
  paymentMethod,
  setPaymentMethod,
  acceptedTerms,
  setAcceptedTerms,
  error,
  loading,
  onPay,
  onBack,
}) => {
  // All payment methods we support (display only)
  const supportedPaymentMethods = [
    { id: "card", label: "Card", icon: CreditCard },
    { id: "apple", label: "Apple Pay", icon: Apple },
    { id: "google", label: "Google Pay", icon: Smartphone },
    { id: "bank", label: "Bank Transfer", icon: Building },
  ];

  const totalAmount = selectedPlan === "full" ? "R2,000.00" : "R1,000.00";

  // Auto-select PayFast when component mounts
  React.useEffect(() => {
    if (!paymentMethod) {
      setPaymentMethod("payfast");
    }
  }, []);

  const handlePayClick = () => {
    if (!loading && acceptedTerms && paymentMethod) {
      onPay?.();
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="text-[10px] font-bold uppercase tracking-[0.25em] mb-3 text-[#C9A227]">Step 4 of 5</div>
        <h1 className="text-white font-bold text-3xl mb-3">Payment</h1>
        <p className="text-sm font-medium max-w-xs mx-auto leading-relaxed text-white/40">
          Complete your payment to secure your spot
        </p>
      </div>

      {error && (
        <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">{error}</div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-[440px_1fr] gap-8">
        {/* Order Summary Card - Left */}
        <div className="flex flex-col gap-5">
          <div className="rounded-2xl p-7 bg-gradient-to-br from-[#151010] to-[#0E0909] border border-white/6 shadow-[0_20px_60px_rgba(0,0,0,0.4)]">
            <div className="text-[10px] font-bold uppercase tracking-[0.2em] mb-6 text-[#C9A227]">Order Summary</div>

            <div className="flex items-center gap-4 p-4 rounded-xl mb-6 bg-white/5 border border-white/6">
              {/* <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 bg-[#C9A227]/15">
                <Crown className="w-5 h-5 text-[#C9A227]" />
              </div> */}
              <div className="flex-1 min-w-0">
                <div className="text-white font-bold text-sm truncate">Purchase tickets for the BRT 150 Black Carpet Gala 2026 Event</div>
                <div className="text-xs font-medium mt-0.5 text-white/35 truncate">BRT 150 Black Carpet Gala · Lagos, 2026</div>
              </div>
              <div className="ml-auto font-bold text-base text-white flex-shrink-0">R2,000</div>
            </div>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between">
                <span className="text-sm font-medium text-white/38">Subtotal</span>
                <span className="text-sm font-semibold text-white/60">R2,000</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-5 border-t border-white/7">
              <span className="text-white font-bold text-lg">Total</span>
              <span className="font-bold text-2xl bg-gradient-to-r from-[#C9A227] to-[#DFBA3A] bg-clip-text text-transparent tracking-[-0.02em]">
                R2,000
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4 p-4 rounded-xl bg-white/[0.02] border border-white/5">
            <div className="flex items-center gap-2 flex-1 justify-center">
              <Shield className="w-3.5 h-3.5 text-[#C9A227]/60" />
              <span className="text-[10px] font-semibold text-white/25">SSL Encrypted</span>
            </div>
            <div className="flex items-center gap-2 flex-1 justify-center">
              <Lock className="w-3.5 h-3.5 text-[#C9A227]/60" />
              <span className="text-[10px] font-semibold text-white/25">PCI DSS Secure</span>
            </div>
            <div className="flex items-center gap-2 flex-1 justify-center">
              <CircleCheckBig className="w-3.5 h-3.5 text-[#C9A227]/60" />
              <span className="text-[10px] font-semibold text-white/25">Verified Payment</span>
            </div>
          </div>
        </div>

        {/* Secure Payment Card - Right */}
        <div className="rounded-2xl p-8 bg-gradient-to-br from-[#151010] to-[#0E0909] border border-white/6 shadow-[0_20px_60px_rgba(0,0,0,0.4)]">
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] mb-7 text-[#C9A227]">Secure Payment</div>

          <div className="flex items-center justify-between p-3.5 rounded-xl mb-7 bg-[#C9A227]/7 border border-[#C9A227]/20">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.15em] text-[#C9A227]">
                {selectedPlan === "full" ? "Full Payment" : "Partial Payment"}
              </div>
              <div className="text-xs font-medium mt-0.5 text-white/40">
                {selectedPlan === "full" ? "R2,000 due today" : `${totalAmount} due today`}
              </div>
            </div>
            <span className="font-black text-lg bg-gradient-to-r from-[#C9A227] to-[#DFBA3A] bg-clip-text text-transparent">
              {totalAmount}
            </span>
          </div>

          <div className="border-t border-white/5 mb-7"></div>

          {/* 
          
         
          <div className="flex items-center justify-center gap-6 p-3 mb-7 bg-[#0A0707] rounded-xl">
            {supportedPaymentMethods.map((method) => {
              const Icon = method.icon;
              return (
                <div key={method.id} className="flex flex-col items-center gap-1.5 opacity-60">
                  <Icon className="w-6 h-6 text-white/60" />
                  <span className="text-[9px] font-medium text-white/30">{method.label}</span>
                </div>
              );
            })}
          </div>

          
          <div className="mb-6 p-4 rounded-xl bg-[#C9A227]/5 border border-[#C9A227]/20 text-center">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Wallet className="w-4 h-4 text-[#C9A227]" />
              <span className="text-xs font-bold text-white/80">Secure Payment via PayFast</span>
            </div>
            <div className="text-[10px] text-white/30">
              You will be redirected to PayFast to complete your payment securely.
              All major credit cards and instant EFT accepted.
            </div>
          </div> */}

          <div className="mt-8">
            <div className="flex items-start gap-3 mb-6">
              <button
                onClick={() => setAcceptedTerms(!acceptedTerms)}
                className={`w-5 h-5 rounded flex items-center justify-center flex-shrink-0 mt-0.5 transition-all ${
                  acceptedTerms ? 'bg-[#C9A227]' : 'bg-white/5 border border-white/10'
                }`}
              >
                {acceptedTerms && <Check className="w-3 h-3 stroke-[3] text-[#050505]" />}
              </button>
              <label className="text-xs leading-relaxed cursor-pointer text-white/30">
                I agree to the{" "}
                <Link
                  to="/terms-and-conditions"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#C9A227] hover:underline"
                >
                  Terms & Conditions
                </Link>{" "}
                and{" "}
                <Link
                  to="/privacy-policy"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[#C9A227] hover:underline"
                >
                  Privacy Policy
                </Link>
                . I understand that tickets are non-refundable.
              </label>
            </div>

            <button
              onClick={handlePayClick}
              disabled={loading || !acceptedTerms || !paymentMethod}
              className="inline-flex items-center justify-center gap-2.5 font-bold rounded-xl transition-all duration-200 active:scale-[0.99] disabled:opacity-40 disabled:cursor-not-allowed w-full px-8 py-4 text-[15px] bg-gradient-to-r from-[#C9A227] to-[#DFBA3A] text-[#050505] shadow-[0_4px_24px_rgba(201,162,39,0.25)]"
            >
              {loading ? (
                <>
                  <div className="w-5 h-5 border-2 border-t-transparent rounded-full animate-spin border-[#050505]" />
                  Processing...
                </>
              ) : (
                <>
                  <Wallet className="w-4 h-4" />
                  Continue to Payment
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PaymentStep;