// components/auth/ApplicationStep.tsx
import React, { useState, useEffect, useRef } from "react";
import { User, Mail, Phone, Building2, Globe, Zap, Check, Briefcase, TrendingUp, Users } from "lucide-react";

interface ApplicationStepProps {
  formData: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    projectDescription: string;
    selectedRole: string; // "entrepreneur" | "professional" | "investor"
    businessUrl: string;
    companyName: string;
    companyUrl: string;
    linkedInUrl: string;
    investmentFocus: string;
  };
  handleInputChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
  setSelectedRole: (role: string) => void;
  error?: string | null;
  onValidationChange?: (isValid: boolean) => void; // Notify parent about validation status
  onEmailCheckingChange?: (checking: boolean) => void; // ✅ NEW: Notify parent about email checking status
}

// Validation helper functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const validatePhone = (phone: string): boolean => {
  // Allow + prefix and digits only, minimum 8 digits
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 8 && digits.length <= 15;
};

const validateUrl = (url: string): boolean => {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return urlObj.protocol === 'http:' || urlObj.protocol === 'https:';
  } catch {
    // Check if it's a social media handle format (like linkedin.com/in/username)
    return /^[a-zA-Z0-9\-._~:/?#[\]@!$&'()*+,;=]+$/.test(url);
  }
};

const validateLinkedInUrl = (url: string): boolean => {
  if (!url) return false;
  // Accept linkedin.com/in/username or full URL format
  const linkedinRegex = /^(https?:\/\/)?(www\.)?linkedin\.com\/in\/[a-zA-Z0-9\-_]+$/;
  return linkedinRegex.test(url) || validateUrl(url);
};

const ApplicationStep: React.FC<ApplicationStepProps> = ({
  formData,
  handleInputChange,
  setSelectedRole,
  error,
  onValidationChange,
  onEmailCheckingChange, // ✅ NEW: Receive the callback
}) => {
  const MAX_PHONE_DIGITS = 15;

  // Local validation state
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});

  // Email check state
  const [isCheckingEmail, setIsCheckingEmail] = useState(false);
  const [emailAvailable, setEmailAvailable] = useState<boolean | null>(null);
  const [emailCheckMessage, setEmailCheckMessage] = useState('');
  const emailCheckTimerRef = useRef<NodeJS.Timeout | null>(null);

  // ✅ NEW: Notify parent about email checking status
  useEffect(() => {
    if (onEmailCheckingChange) {
      onEmailCheckingChange(isCheckingEmail);
    }
  }, [isCheckingEmail, onEmailCheckingChange]);

  // Validation function
  const validateField = (field: string, value: any): string => {
    switch (field) {
      case 'firstName':
        if (!value || value.trim().length < 2) return 'First name is required (minimum 2 characters)';
        if (value.trim().length > 50) return 'First name must be less than 50 characters';
        return '';

      case 'lastName':
        if (!value || value.trim().length < 2) return 'Last name is required (minimum 2 characters)';
        if (value.trim().length > 50) return 'Last name must be less than 50 characters';
        return '';

      case 'email':
        if (!value) return 'Email address is required';
        if (!validateEmail(value)) return 'Please enter a valid email address (e.g., name@domain.com)';
        // Check if email is confirmed as unavailable
        if (emailAvailable === false) {
          return 'This email address is already registered';
        }
        return '';

      case 'phone':
        if (!value) return 'Phone number is required';
        if (!validatePhone(value)) return 'Please enter a valid phone number (minimum 8 digits)';
        return '';

      case 'selectedRole':
        if (!value) return 'Please select your role (Entrepreneur, Professional, or Investor)';
        return '';

      case 'businessUrl':
        if (formData.selectedRole === 'entrepreneur') {
          if (!value || !validateUrl(value)) {
            return 'Please enter a valid business URL (e.g., https://yourbusiness.com)';
          }
        }
        return '';

      case 'companyName':
        if (formData.selectedRole === 'professional') {
          if (!value || value.trim().length < 2) {
            return 'Company/Employer name is required (minimum 2 characters)';
          }
          if (value.trim().length > 100) return 'Company name must be less than 100 characters';
        }
        return '';

      case 'companyUrl':
        if (formData.selectedRole === 'professional') {
          if (!value || !validateUrl(value)) {
            return 'Please enter a valid company URL (e.g., https://yourcompany.co.za)';
          }
        }
        return '';

      case 'linkedInUrl':
        if (formData.selectedRole === 'investor') {
          if (!value || !validateLinkedInUrl(value)) {
            return 'Please enter a valid LinkedIn URL (e.g., linkedin.com/in/username)';
          }
        }
        return '';

      default:
        return '';
    }
  };

  // Check email availability
  const checkEmailAvailability = async (email: string) => {
    if (!validateEmail(email)) return;

    setIsCheckingEmail(true);
    setEmailAvailable(null);
    setEmailCheckMessage('');

    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/check-email`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const data = await response.json();

      if (response.ok && data.success) {
        if (data.data.available) {
          setEmailAvailable(true);
          setEmailCheckMessage('✅ Email is available for ticket purchase');
          // Clear any previous email error
          setFieldErrors(prev => ({ ...prev, email: '' }));
        } else {
          setEmailAvailable(false);
          setEmailCheckMessage('❌ This email is already registered for a ticket');
          // Set field error
          setFieldErrors(prev => ({
            ...prev,
            email: 'This email already has a ticket. Please use a different email.'
          }));
        }
      } else {
        // Handle API error
        setEmailCheckMessage('⚠️ Unable to verify email. Please try again.');
        setEmailAvailable(null);
      }
    } catch (error) {
      console.error('Email check error:', error);
      setEmailCheckMessage('⚠️ Network error. Please check your connection.');
      setEmailAvailable(null);
    } finally {
      setIsCheckingEmail(false);
    }
  };

  // Validate all fields
  const validateAll = (): Record<string, string> => {
    const errors: Record<string, string> = {};

    // Personal details (always required)
    errors.firstName = validateField('firstName', formData.firstName);
    errors.lastName = validateField('lastName', formData.lastName);
    errors.email = validateField('email', formData.email);
    errors.phone = validateField('phone', formData.phone);
    errors.selectedRole = validateField('selectedRole', formData.selectedRole);

    // Conditional fields based on role
    if (formData.selectedRole === 'entrepreneur') {
      errors.businessUrl = validateField('businessUrl', formData.businessUrl);
    } else if (formData.selectedRole === 'professional') {
      errors.companyName = validateField('companyName', formData.companyName);
      errors.companyUrl = validateField('companyUrl', formData.companyUrl);
    } else if (formData.selectedRole === 'investor') {
      errors.linkedInUrl = validateField('linkedInUrl', formData.linkedInUrl);
    }

    return errors;
  };

  // Check if all required fields are valid (for parent component)
  const isFormValid = (): boolean => {
    const errors = validateAll();
    const requiredFields = ['firstName', 'lastName', 'email', 'phone', 'selectedRole'];

    // Add conditional required fields
    if (formData.selectedRole === 'entrepreneur') {
      requiredFields.push('businessUrl');
    } else if (formData.selectedRole === 'professional') {
      requiredFields.push('companyName', 'companyUrl');
    } else if (formData.selectedRole === 'investor') {
      requiredFields.push('linkedInUrl');
    }

    // Also check that email is available (if email is filled)
    const isEmailValid = emailAvailable !== false;

    return requiredFields.every(field => !errors[field]) && isEmailValid;
  };

  // Notify parent about validation status
  useEffect(() => {
    if (onValidationChange) {
      const isValid = isFormValid();
      onValidationChange(isValid);
    }
  }, [formData, emailAvailable, onValidationChange]);

  // Cleanup timer on unmount
  useEffect(() => {
    return () => {
      if (emailCheckTimerRef.current) {
        clearTimeout(emailCheckTimerRef.current);
      }
    };
  }, []);

  // Handle field validation on change
  const handleFieldChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    handleInputChange(e);

    // Validate on change if field was touched
    if (touched[id]) {
      const error = validateField(id, value);
      setFieldErrors(prev => ({ ...prev, [id]: error }));
    }

    // Check email availability with debounce
    if (id === 'email') {
      // Clear any existing timer
      if (emailCheckTimerRef.current) {
        clearTimeout(emailCheckTimerRef.current);
      }

      // Only check if email format is valid
      if (validateEmail(value)) {
        // Reset email availability status while typing
        setEmailAvailable(null);
        setEmailCheckMessage('');

        // Set new timer with 500ms delay
        emailCheckTimerRef.current = setTimeout(() => {
          checkEmailAvailability(value);
        }, 500);
      } else {
        // Clear status if email format is invalid
        setEmailAvailable(null);
        setEmailCheckMessage('');
        // Clear email error if any
        setFieldErrors(prev => ({ ...prev, email: '' }));
      }
    }
  };

  // Handle field blur for validation
  const handleFieldBlur = (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target;
    setTouched(prev => ({ ...prev, [id]: true }));
    const error = validateField(id, value);
    setFieldErrors(prev => ({ ...prev, [id]: error }));
  };

  // Handle role selection with validation
  const handleRoleSelect = (role: string) => {
    const newRole = formData.selectedRole === role ? "" : role;
    setSelectedRole(newRole);

    // Clear errors for role
    setFieldErrors(prev => ({ ...prev, selectedRole: '' }));

    // Clear conditional field errors if role is deselected
    if (!newRole) {
      setFieldErrors(prev => ({
        ...prev,
        businessUrl: '',
        companyName: '',
        companyUrl: '',
        linkedInUrl: '',
      }));
    }
  };

  // Strips everything except digits (keeps a leading "+" if the user typed one)
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const raw = e.target.value;
    const hasPlus = raw.trim().startsWith("+");
    const digitsOnly = raw.replace(/\D/g, "").slice(0, MAX_PHONE_DIGITS);
    const cleaned = hasPlus ? `+${digitsOnly}` : digitsOnly;

    const syntheticEvent = {
      ...e,
      target: { ...e.target, id: "phone", value: cleaned },
    } as React.ChangeEvent<HTMLInputElement>;

    handleFieldChange(syntheticEvent);
  };

  const isEntrepreneur = formData.selectedRole === "entrepreneur";
  const isProfessional = formData.selectedRole === "professional";
  const isInvestor = formData.selectedRole === "investor";

  const showProfessionalSection = formData.selectedRole !== "entrepreneur";
  const showInvestorSection = formData.selectedRole !== "entrepreneur" && formData.selectedRole !== "professional";

  const visibleRoleSectionCount = 1 + (showProfessionalSection ? 1 : 0) + (showInvestorSection ? 1 : 0);
  const companyStepNumber = String(2 + visibleRoleSectionCount).padStart(2, "0");

  // Helper to get error message
  const getError = (field: string): string | undefined => {
    if (touched[field] || field === 'selectedRole') {
      return fieldErrors[field];
    }
    return undefined;
  };

  // Helper to determine if field has error
  const hasError = (field: string): boolean => {
    return !!getError(field);
  };

  return (
    <div className="space-y-0 application-step">
      {/* Section 1: Personal Details */}
      <div>
        <div className="mb-4">
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] mb-1 text-[#C9A227]">01</div>
          <div className="text-white font-bold text-base">Personal Details</div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* First Name */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              First Name *
            </label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="firstName"
                type="text"
                value={formData.firstName}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                placeholder="James"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('firstName')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope']`}
              />
            </div>
            {hasError('firstName') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('firstName')}</p>
            )}
          </div>

          {/* Last Name */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Last Name *
            </label>
            <div className="relative">
              <User className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="lastName"
                type="text"
                value={formData.lastName}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                placeholder="Mokoena"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('lastName')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope']`}
              />
            </div>
            {hasError('lastName') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('lastName')}</p>
            )}
          </div>

          {/* Email - Updated with email check */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Email Address *
            </label>
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="email"
                type="email"
                value={formData.email}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                placeholder="james@company.co.za"
                className={`w-full rounded-xl py-3.5 pl-11 pr-12 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('email')
                    ? 'border-red-500 focus:border-red-500'
                    : emailAvailable === true && formData.email && !isCheckingEmail
                      ? 'border-green-500 focus:border-green-500'
                      : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope']`}
              />

              {/* Email check status indicator */}
              {isCheckingEmail && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-[#C9A227] border-t-transparent"></div>
                </div>
              )}

              {emailAvailable === true && !isCheckingEmail && formData.email && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                  <Check className="w-4 h-4 text-green-500" />
                </div>
              )}

              {emailAvailable === false && !isCheckingEmail && formData.email && (
                <div className="absolute right-4 top-1/2 -translate-y-1/2">
                  <span className="text-red-500 text-lg font-bold">✕</span>
                </div>
              )}
            </div>

            {/* Email status messages */}
            {emailCheckMessage && !hasError('email') && (
              <p className={`text-xs mt-1.5 ${emailAvailable === true ? 'text-green-400' :
                  emailAvailable === false ? 'text-red-400' :
                    'text-yellow-400'
                }`}>
                {emailCheckMessage}
              </p>
            )}

            {hasError('email') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('email')}</p>
            )}
          </div>

          {/* Phone */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Phone Number *
            </label>
            <div className="relative">
              <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="phone"
                type="tel"
                inputMode="numeric"
                maxLength={16}
                value={formData.phone}
                onChange={handlePhoneChange}
                onBlur={handleFieldBlur}
                placeholder="+27 800 000 000"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('phone')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope']`}
              />
            </div>
            {hasError('phone') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('phone')}</p>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
          {error}
        </div>
      )}

      {/* Divider */}
      <div className="my-8 border-t border-white/5" />

      {/* Section 3: Are you an Entrepreneur? — always visible */}
      <RoleToggleSection
        number="02"
        title="Are you an Entrepreneur?"
        subtitle="Building or leading a business or startup"
        icon={Zap}
        cardTitle="I'm an Entrepreneur"
        cardDescription="Startup founder, business owner or scaleup leader"
        selected={isEntrepreneur}
        locked={!!formData.selectedRole && !isEntrepreneur}
        onSelect={() => handleRoleSelect("entrepreneur")}
        hasError={hasError('selectedRole') && !formData.selectedRole}
        errorMessage={getError('selectedRole')}
      />

      {/* Section 4: Are you a Professional? — hidden once Entrepreneur is picked */}
      {showProfessionalSection && (
        <>
          <div className="my-8 border-t border-white/5" />
          <RoleToggleSection
            number="03"
            title="Are you a Professional?"
            subtitle="Accountant, attorney, doctor, engineer, executive or similar"
            icon={Briefcase}
            cardTitle="I'm a Professional"
            cardDescription="Qualified professional with capacity to engage or invest"
            selected={isProfessional}
            locked={!!formData.selectedRole && !isProfessional}
            onSelect={() => handleRoleSelect("professional")}
            hasError={hasError('selectedRole') && !formData.selectedRole}
            errorMessage={getError('selectedRole')}
          />
        </>
      )}

      {/* Section 5: Are you an Investor? — hidden once Entrepreneur or Professional is picked */}
      {showInvestorSection && (
        <>
          <div className="my-8 border-t border-white/5" />
          <RoleToggleSection
            number="04"
            title="Are you an Investor?"
            subtitle="VC, angel, PE, family office or active investment vehicle"
            icon={TrendingUp}
            cardTitle="I'm an Investor"
            cardDescription="Capital allocator or active investment vehicle"
            selected={isInvestor}
            locked={!!formData.selectedRole && !isInvestor}
            onSelect={() => handleRoleSelect("investor")}
            hasError={hasError('selectedRole') && !formData.selectedRole}
            errorMessage={getError('selectedRole')}
          />
        </>
      )}

      {/* Message reinforcing what happens next for the selected role */}
      {formData.selectedRole && !isEntrepreneur && (
        <div className="mt-6 p-4 rounded-xl bg-white/5 border border-white/5">
          <p className="text-sm text-white/40 text-center">
            {isProfessional
              ? "As a Professional, you'll be able to engage with entrepreneurs and explore investment opportunities."
              : "As an Investor, you'll get access to curated investment opportunities and pitch sessions."}
          </p>
        </div>
      )}

      {/* Divider */}
      <div className="my-8 border-t border-white/5" />

      {/* Section: URL Link to Company */}
      <div>
        <div className="mb-4">
          <div className="text-[10px] font-bold uppercase tracking-[0.2em] mb-1 text-[#C9A227]">
            {companyStepNumber}
          </div>
          <div className="text-white font-bold text-base">URL Link to Company</div>
          <div className="text-xs font-medium mt-0.5 text-white/28">Web link / social media link</div>
        </div>

        <div className="space-y-4">
          {/* Business URL — Entrepreneur only */}
          <div className={!isEntrepreneur ? "opacity-30" : undefined}>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Business URL {isEntrepreneur && "*"}
            </label>
            <div className="relative">
              <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="businessUrl"
                type="url"
                value={formData.businessUrl}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                disabled={!isEntrepreneur}
                placeholder="https://yourbusiness.com or social media page"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('businessUrl')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope'] disabled:cursor-not-allowed`}
              />
            </div>
            <p className="text-[11px] font-medium mt-1.5 text-white/28">
              You can provide a website link or a social media page link (Facebook, Instagram, LinkedIn, etc.)
            </p>
            {hasError('businessUrl') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('businessUrl')}</p>
            )}
          </div>

          {/* Company / Employer Name — Professional only */}
          <div className={!isProfessional ? "opacity-30" : undefined}>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Company / Employer Name {isProfessional && "*"}
            </label>
            <div className="relative">
              <Building2 className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="companyName"
                type="text"
                value={formData.companyName}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                disabled={!isProfessional}
                placeholder="e.g. Smith & Associates, City of Johannesburg…"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('companyName')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope'] disabled:cursor-not-allowed`}
              />
            </div>
            {hasError('companyName') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('companyName')}</p>
            )}
          </div>

          {/* Company URL — Professional only */}
          <div className={!isProfessional ? "opacity-30" : undefined}>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Company URL {isProfessional && "*"}
            </label>
            <div className="relative">
              <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="companyUrl"
                type="url"
                value={formData.companyUrl}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                disabled={!isProfessional}
                placeholder="https://yourcompany.co.za or LinkedIn company page"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('companyUrl')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope'] disabled:cursor-not-allowed`}
              />
            </div>
            <p className="text-[11px] font-medium mt-1.5 text-white/28">
              Website or social media page — whichever best represents your organisation
            </p>
            {hasError('companyUrl') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('companyUrl')}</p>
            )}
          </div>

          {/* LinkedIn URL — Investor only */}
          <div className={!isInvestor ? "opacity-30" : undefined}>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              LinkedIn Profile URL {isInvestor && "*"}
            </label>
            <div className="relative">
              <Globe className="absolute left-4 top-1/2 -translate-y-1/2 w-[14px] h-[14px] text-white/30" />
              <input
                id="linkedInUrl"
                type="text"
                value={formData.linkedInUrl}
                onChange={handleFieldChange}
                onBlur={handleFieldBlur}
                disabled={!isInvestor}
                placeholder="linkedin.com/in/yourprofile"
                className={`w-full rounded-xl py-3.5 pl-11 pr-4 text-sm text-white placeholder-white/30 outline-none transition-all duration-200 bg-[#0A0707] border ${hasError('linkedInUrl')
                    ? 'border-red-500 focus:border-red-500'
                    : 'border-white/7 focus:border-[#C9A227]'
                  } font-['Manrope'] disabled:cursor-not-allowed`}
              />
            </div>
            {hasError('linkedInUrl') && (
              <p className="text-red-400 text-xs mt-1.5">{getError('linkedInUrl')}</p>
            )}
          </div>

          {/* Investment Focus — Investor only */}
          <div className={!isInvestor ? "opacity-30" : undefined}>
            <label className="block text-[10px] font-bold uppercase tracking-[0.18em] mb-2 text-white/35">
              Investment Focus (optional)
            </label>
            <textarea
              id="investmentFocus"
              rows={2}
              value={formData.investmentFocus}
              onChange={handleInputChange}
              disabled={!isInvestor}
              placeholder="e.g. fintech, property, agri, technology startups…"
              className="w-full rounded-xl px-4 py-3 text-sm text-white placeholder-white/30 outline-none resize-none transition-all duration-200 bg-[#0A0707] border border-white/7 focus:border-[#C9A227] font-['Manrope'] disabled:cursor-not-allowed"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

/* ---------------------------------------------------------------------- */
/* Reusable single-toggle "role" section with error support               */
/* ---------------------------------------------------------------------- */

interface RoleToggleSectionProps {
  number: string;
  title: string;
  subtitle: string;
  icon: React.ComponentType<{ className?: string }>;
  cardTitle: string;
  cardDescription: string;
  selected: boolean;
  locked: boolean;
  onSelect: () => void;
  hasError?: boolean;
  errorMessage?: string;
}

const RoleToggleSection: React.FC<RoleToggleSectionProps> = ({
  number,
  title,
  subtitle,
  icon: Icon,
  cardTitle,
  cardDescription,
  selected,
  locked,
  onSelect,
  hasError,
  errorMessage,
}) => {
  return (
    <div>
      <div className="mb-4">
        <div className="text-[10px] font-bold uppercase tracking-[0.2em] mb-1 text-[#C9A227]">{number}</div>
        <div className="text-white font-bold text-base">{title}</div>
        <div className="text-xs font-medium mt-0.5 text-white/28">{subtitle}</div>
      </div>

      <button
        type="button"
        disabled={locked}
        onClick={onSelect}
        aria-disabled={locked}
        className={`w-full flex items-center gap-4 p-4 rounded-xl text-left transition-all duration-200 ${selected
            ? "bg-[#C9A227]/10 border border-[#C9A227] shadow-[0_0_28px_rgba(201,162,39,0.15)] cursor-pointer"
            : locked
              ? "bg-transparent border border-white/5 opacity-20 cursor-not-allowed"
              : hasError
                ? "bg-transparent border border-red-500/50 opacity-60 cursor-pointer hover:opacity-80"
                : "bg-transparent border border-white/5 opacity-40 hover:opacity-60 cursor-pointer"
          }`}
      >
        <div
          className={`w-11 h-11 rounded-xl flex items-center justify-center flex-shrink-0 ${selected ? "bg-[#C9A227]/20" : "bg-white/5"
            }`}
        >
          <Icon className={`w-[18px] h-[18px] ${selected ? "text-[#C9A227]" : "text-white/25"}`} />
        </div>
        <div className="flex-1 min-w-0">
          <div className={`font-bold text-sm ${selected ? "text-[#C9A227]" : "text-white/40"}`}>
            {cardTitle}
          </div>
          <div className="text-xs font-medium mt-0.5 text-white/25">{cardDescription}</div>
        </div>
        <div
          className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 ${selected ? "bg-gradient-to-r from-[#C9A227] to-[#DFBA3A]" : "border border-white/15"
            }`}
        >
          {selected && <Check className="w-[10px] h-[10px]" strokeWidth={3} style={{ color: "#050505" }} />}
        </div>
      </button>

      {hasError && !selected && errorMessage && (
        <p className="text-red-400 text-xs mt-2">{errorMessage}</p>
      )}
    </div>
  );
};

export default ApplicationStep;