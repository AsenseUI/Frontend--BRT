import React from "react";
import {
  MapPin,
  Calendar,
  Clock,
  Users,
  ExternalLink,
} from "lucide-react";
import image5 from "@/assets/home/image5.png";

const Venue = () => {
const details = [
  {
    icon: MapPin,
    label: "Location",
    value: "Ethereal, Newcastle, KwaZulu-Natal",
  },
  {
    icon: Calendar,
    label: "Date",
    value: "21 November 2026",
  },
  {
    icon: Clock,
    label: "Time",
    value: "16:00 for 17:00 - 21:00",
  },
  {
    icon: Users,
    label: "Capacity",
    value: "150 Guests",
  },
];

  // Replace this with the exact Google Maps share link if you have one
  const mapUrl =
    "https://www.google.com/maps/search/?api=1&query=Ethereal,+Newcastle,+KwaZulu-Natal";

  return (
    <section className="py-[100px_24px] bg-[#111827] mobilepad" id="venue">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          {/* <div className="text-[11px] font-bold tracking-[0.25em] text-[#d4af37]/70 uppercase mb-[14px]">
            Location
          </div> */}

          <h2 className="text-[clamp(1.8rem,4vw,2.8rem)] font-extrabold text-white tracking-[-0.02em]">
            Event Details
          </h2>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
          {/* Venue Image */}
          <div className="relative rounded-2xl overflow-hidden">
            <img
              src={image5}
              alt="Luxury event venue"
              className="w-full h-[400px] object-cover rounded-2xl"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-2xl" />
          </div>

          {/* Venue Details */}
          <div>
            <div className="bg-gradient-to-br from-white/5 to-white/0 border border-[#d4af37]/50 rounded-2xl backdrop-blur-md shadow-[0_0_40px_rgba(212,175,55,0.1),0_20px_60px_rgba(0,0,0,0.4)] p-9 mb-5">
              <div className="text-[11px] font-bold tracking-[0.2em] text-[#d4af37] uppercase mb-4">
                Venue Details
              </div>

              {details.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center gap-3.5 mb-4 last:mb-0"
                >
                  <div className="w-[38px] h-[38px] rounded-[10px] bg-[#d4af37]/15 flex items-center justify-center flex-shrink-0 border border-[#d4af37]/25">
                    <item.icon size={15} className="text-[#d4af37]" />
                  </div>

                  <div>
                    <div className="text-[10px] font-bold text-white/35 tracking-[0.15em] uppercase">
                      {item.label}
                    </div>

                    <div className="text-sm font-semibold text-white/80 mt-0.5">
                      {item.value}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Clickable Google Maps Card */}
            <a
              href={mapUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="block group"
            >
              <div className="bg-gradient-to-br from-white/5 to-white/0 border border-white/10 rounded-2xl backdrop-blur-md shadow-[0_20px_60px_rgba(0,0,0,0.3)] overflow-hidden h-[160px] transition-all duration-300 hover:border-[#d4af37] hover:shadow-[0_0_25px_rgba(212,175,55,0.25)] cursor-pointer">
                <div className="w-full h-full bg-gradient-to-br from-[#111827]/80 to-[#0a0a0a]/80 flex items-center justify-center gap-3 px-6">
                  <MapPin
                    size={22}
                    className="text-[#d4af37] group-hover:scale-110 transition-transform"
                  />

                  <span className="text-sm font-semibold text-white group-hover:text-[#d4af37] transition-colors">
                    Ethereal, Newcastle, KwaZulu-Natal
                  </span>

                  <ExternalLink
                    size={16}
                    className="text-[#d4af37] group-hover:translate-x-1 transition-transform"
                  />
                </div>
              </div>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Venue;
