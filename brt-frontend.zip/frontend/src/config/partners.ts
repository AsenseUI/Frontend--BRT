// config/partners.ts
export interface Partner {
    name: string;
    label: string;
    logoUrl: string;
    displayOrder: number;
}

// Partners in the correct order as specified
export const PARTNERS: Partner[] = [
    {
        name: 'Audi Centre Newcastle',
        label: 'Automotive Partner',
        logoUrl: '/assets/audi-CvtehD6T.png',
        displayOrder: 1
    },
    {
        name: 'Izinhloli Security Services',
        label: 'Security Partner',
        logoUrl: '/assets/izinhlloi-CpVS8ylZ.jpeg',
        displayOrder: 2
    },
    {
        name: 'Amajuba District Municipality',
        label: 'Government Partner',
        logoUrl: '/assets/amajuba--UQtNyNl.png',
        displayOrder: 3
    },
    {
        name: 'Royal Chicken',
        label: 'Food Partner',
        logoUrl: '/assets/royal-chicken-2Gke4PLR.jpeg',
        displayOrder: 4
    },
    {
        name: 'VVG (Vivid Vision Graphics)',
        label: 'Graphics Partner',
        logoUrl: '/assets/vivid-vision-DtuvwUqD.jpeg',
        displayOrder: 5
    },
    {
        name: 'CT Creatrend',
        label: 'Creative Partner',
        logoUrl: '/assets/ct-creatrend-dyf7mRTH.jpeg',
        displayOrder: 6
    },
    {
        name: 'Elevate Systems',
        label: 'Technology Partner',
        logoUrl: '/assets/digital-consulting-CV2f7BCj.jpeg',
        displayOrder: 7
    },
    {
        name: 'Pluto',
        label: 'Brand Partner',
        logoUrl: '/assets/pluto-HI8YQOzA.jpeg',
        displayOrder: 8
    },
    {
        name: 'Ethereal',
        label: 'Venue Partner',
        logoUrl: '/assets/ethereal-CGDcVTWc.jpeg',
        displayOrder: 9
    },
    {
        name: 'N Ndlovu Attorneys',
        label: 'Legal Partner',
        logoUrl: '/assets/nndlovu-attorneys-BRqfK_AM.jpeg',
        displayOrder: 10
    },
    {
        name: 'Esihle Networks Co.',
        label: 'Legal Partner',
        logoUrl: '/assets/esihle-Cua15Z_J.jpeg',
        displayOrder: 10
    }
];

// Sort partners by display order
export const getSortedPartners = (): Partner[] => {
    return [...PARTNERS].sort((a, b) => a.displayOrder - b.displayOrder);
};

// Get partners for grid display (2 columns)
export const getPartnersGrid = (): Partner[][] => {
    const sorted = getSortedPartners();
    const grid: Partner[][] = [];
    for (let i = 0; i < sorted.length; i += 2) {
        grid.push(sorted.slice(i, i + 2));
    }
    return grid;
};