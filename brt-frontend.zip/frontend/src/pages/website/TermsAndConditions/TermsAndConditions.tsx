// pages/TermsAndConditions.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  FileText, 
  Shield, 
  Scale, 
  AlertCircle, 
  Mail, 
  BookOpen, 
  Eye, 
  Calendar, 
  Building2,
  CreditCard,
  Users,
  Camera,
  Gavel,
  Info,
  Clock
} from 'lucide-react';

function TermsAndConditions() {
  return (
    <div className="min-h-screen bg-black text-white font-manrope">

      {/* Main Content */}
      <div className="pt-[62px]">
        <div className="max-w-[1400px] mx-auto px-6 py-16">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-16 h-16 rounded-2xl bg-[#C9A227]/10 flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-[#C9A227]" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
              Terms and Conditions
            </h1>
            <p className="text-sm text-white/40">
              The Brt (Pty) Ltd Registration Number: 2026/382883/07
            </p>
            <p className="text-xs text-white/20 mt-1">
              Effective Date: 7 July 2026
            </p>
          </div>

          {/* Terms Content */}
          <div className="space-y-6">
            {/* Introduction */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Info className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">1. Introduction and Acceptance</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  These Terms and Conditions ("Terms") govern your attendance at and participation in events hosted by{' '}
                  <span className="text-white/80">The Black Roundtable (Pty) Ltd ("BRT", "we", "us", "our")</span>,{' '}
                  registered in South Africa with registration number <span className="text-white/80">2026/382883/07</span>,{' '}
                  headquartered in Newcastle, KwaZulu-Natal.
                </p>
                <p>
                  By purchasing a ticket to a BRT event, accepting an invitation to attend, or engaging with BRT in any{' '}
                  capacity in relation to our events, you ("you", "your", "the Attendee") confirm that you have read,{' '}
                  understood, and agree to be bound by these Terms in their entirety.
                </p>
                <p>
                  If you do not agree, you must not proceed with your ticket purchase or attendance.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    These Terms must be read together with our Privacy Policy, which is incorporated herein by reference{' '}
                    and forms part of this agreement. Both documents are available on our website at{' '}
                    <a href="https://www.thebrtsa.com" target="_blank" rel="noopener noreferrer" className="text-[#C9A227] hover:underline">
                      www.thebrtsa.com
                    </a>
                  </p>
                </div>
                <p>
                  BRT reserves the right to amend these Terms at any time. Amendments will be published on our website{' '}
                  with a revised effective date. Your continued engagement with BRT following such publication{' '}
                  constitutes your acceptance of the updated Terms.
                </p>
              </div>
            </section>

            {/* About BRT */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Building2 className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">2. About BRT and the BRT Black Carpet Gala</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  <span className="text-white/80">The Black Roundtable (Pty) Ltd</span> is a premium event company{' '}
                  headquartered in Newcastle, KwaZulu-Natal. Our flagship occasion is the{' '}
                  <span className="text-white/80">BRT Black Carpet Gala</span> - an annual black-tie event that brings{' '}
                  together founders, investors, financiers, executives, and senior professionals for an evening of{' '}
                  curated networking, keynote addresses, panel discussions, and thought leadership.
                </p>
                <p>
                  The Gala is a carefully curated, invitation-only or ticketed event. Every aspect of the evening -{' '}
                  from guest selection and programme content to venue, production, and hospitality - is designed and{' '}
                  managed to a premium standard.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    Attendance at the Gala does not guarantee any specific business outcome, introduction, or commercial result.
                  </p>
                </div>
                <p>
                  BRT manages all aspects of the event, including the programme, guest list, speakers, and venue,{' '}
                  at its sole discretion.
                </p>
              </div>
            </section>

            {/* Tickets and Purchasing */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <CreditCard className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">3. Tickets and Purchasing</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">3.1 Ticket Availability</h3>
                  <p>
                    Tickets to BRT events are made available in phases, at prices published on our website and{' '}
                    communicated through official BRT channels. Ticket availability is limited and is not guaranteed{' '}
                    until full payment or a confirmed partial payment arrangement has been received and acknowledged{' '}
                    by BRT in writing.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">3.2 Ticket Phases</h3>
                  <p>
                    BRT may release tickets across multiple phases at different price points. The price applicable to{' '}
                    your ticket is the price at the time of your purchase. BRT is not obligated to honour a lower price{' '}
                    from a previous phase once that phase has closed.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">3.3 Payment</h3>
                  <p>
                    Payment must be made in full at the time of purchase unless a partial payment arrangement has been{' '}
                    specifically agreed with BRT in writing prior to purchase. All prices are inclusive of VAT where applicable.
                  </p>
                  <p className="mt-1">
                    BRT accepts payment through the payment methods published on our website. By making a payment,{' '}
                    you agree to the terms and conditions of the relevant third-party payment processor.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">3.4 Confirmation</h3>
                  <p>
                    Your ticket purchase is confirmed only upon receipt of a written confirmation from BRT. BRT reserves{' '}
                    the right to decline or cancel a ticket purchase at its sole discretion, in which case a full refund{' '}
                    of the amount paid will be issued.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">3.5 Ticket Validity</h3>
                  <p>
                    Each ticket is valid for one named attendee only. Tickets are non-transferable except in accordance{' '}
                    with Section 5.6 of these Terms. BRT reserves the right to verify the identity of attendees at the event.
                  </p>
                </div>
              </div>
            </section>

            {/* Attendance and Conduct */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">4. Attendance and Conduct</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">4.1 Right of Admission</h3>
                  <p>
                    BRT reserves the right to refuse admission to any person or to remove any person from the event at{' '}
                    any time, without refund, where that person's conduct, behaviour, or presence is deemed by BRT to be{' '}
                    inconsistent with the standards, values, safety, or reputation of the event. This right is exercised{' '}
                    at BRT's sole discretion.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">4.2 Professional Conduct</h3>
                  <p>
                    All attendees are expected to conduct themselves with the highest standard of professionalism and{' '}
                    courtesy throughout the event. Behaviour that is disruptive, offensive, discriminatory, threatening,{' '}
                    intoxicated, or unlawful will result in immediate removal from the event without refund.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">4.3 Dress Code</h3>
                  <p>
                    The BRT Black Carpet Gala is a black-tie occasion. Strict adherence to the dress code is required of{' '}
                    all attendees. BRT reserves the right to decline entry to any guest who does not meet the black-tie{' '}
                    dress standard, without refund, subject to your rights under the Consumer Protection Act 68 of 2008{' '}
                    ("CPA") where applicable.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">4.4 Punctuality</h3>
                  <p>
                    The event programme begins at the time communicated in official BRT correspondence. BRT is not{' '}
                    obligated to delay or repeat any element of the programme for late arrivals.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">4.5 Health and Safety</h3>
                  <p>
                    All attendees must comply with the health and safety rules of the venue and any lawful instructions{' '}
                    issued by BRT staff, venue management, or security personnel during the event.
                  </p>
                </div>
              </div>
            </section>

            {/* Refund and Cancellation */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">5. Refund and Cancellation Policy</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">5.1 General Position</h3>
                  <p>
                    The BRT Black Carpet Gala involves significant advance financial commitments to venues, catering,{' '}
                    production, entertainment, and staffing, all of which are contracted based on confirmed attendance{' '}
                    numbers. For this reason, tickets are generally non-refundable once purchased.
                  </p>
                  <div className="p-4 bg-white/5 rounded-xl mt-2">
                    <p className="text-xs text-white/40">
                      We acknowledge, however, that the Consumer Protection Act 68 of 2008 ("CPA") affords certain{' '}
                      protections to consumers, and BRT is committed to treating all attendees fairly and in accordance{' '}
                      with applicable law. Where the CPA applies to your purchase, nothing in this policy limits or{' '}
                      excludes rights to which you are entitled under the CPA.
                    </p>
                  </div>
                  <p className="mt-2">
                    We encourage all prospective attendees to carefully confirm their availability and circumstances{' '}
                    before completing a ticket purchase. If you have any questions about the event prior to purchasing,{' '}
                    please contact us at <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline">info@thebrtsa.com</a> before completing your transaction.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">5.2 Cancellation by BRT - Full Cancellation</h3>
                  <p>
                    If BRT cancels the event entirely and does not reschedule within a reasonable period, all ticket{' '}
                    holders will be entitled to a full refund of the ticket price paid.
                  </p>
                  <p className="mt-1">
                    Refunds will be processed within 14 business days of the official cancellation announcement, using{' '}
                    the original payment method where possible.
                  </p>
                  <div className="p-4 bg-red-500/5 border border-red-500/10 rounded-xl mt-2">
                    <p className="text-xs text-red-400/60">
                      BRT will not be liable for any additional costs incurred by attendees in anticipation of the event,{' '}
                      including but not limited to travel, accommodation, clothing, styling, or any other personal expenses.
                    </p>
                  </div>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">5.3 Cancellation by BRT - Postponement</h3>
                  <p>
                    Where BRT postpones the event to a date more than six months from the originally scheduled date,{' '}
                    ticket holders will be given the option to:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-white/60 ml-4 mt-1">
                    <li>Transfer their ticket to the rescheduled date at no additional cost, or</li>
                    <li>Request a full refund of the ticket price paid</li>
                  </ul>
                  <p className="mt-1">
                    Ticket holders must notify BRT in writing of their election within 14 days of the postponement{' '}
                    announcement. Failure to notify BRT within this period will be deemed acceptance of the rescheduled{' '}
                    date, and no refund will be issued thereafter.
                  </p>
                  <p className="mt-1">
                    Where the event is postponed to a date within six months of the original date, tickets will be{' '}
                    automatically transferred to the new date. No refund will be offered in this instance, except where{' '}
                    the CPA affords you a right to cancel.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">5.6 Ticket Transfers</h3>
                  <p>
                    Where a ticket holder is unable to attend, they may transfer their ticket to another named individual{' '}
                    at no additional cost, subject to the following conditions:
                  </p>
                  <ul className="list-disc list-inside space-y-1 text-white/60 ml-4 mt-1">
                    <li>Written notice of the transfer, including the full name and contact details of the replacement guest, must be provided to BRT at least 72 hours before the event</li>
                    <li>The replacement guest must meet BRT's attendance criteria and dress code requirements</li>
                    <li>BRT reserves the right to decline a transfer where the replacement guest is deemed unsuitable, at BRT's sole discretion</li>
                    <li>Tickets may not be transferred more than once</li>
                    <li>Tickets may not be resold or offered for sale at a price exceeding the original purchase price. Any such resale will render the ticket void</li>
                  </ul>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">5.8 How to Request a Refund</h3>
                  <p>
                    All refund requests must be submitted in writing to <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline">info@thebrtsa.com</a> with the subject line{' '}
                    "Refund Request - [Your Full Name] - [Event Name]", and must include your full name, the email address{' '}
                    used at the time of purchase, and proof of payment.
                  </p>
                  <p className="mt-1">
                    BRT will acknowledge your request within 3 business days and process eligible refunds within 14{' '}
                    business days of approval. Refunds will be made via the original payment method where possible.
                  </p>
                  <div className="p-4 bg-white/5 rounded-xl mt-2">
                    <p className="text-xs text-white/40">
                      BRT is not responsible for delays caused by third-party payment processors or banking institutions.
                    </p>
                  </div>
                </div>
              </div>
            </section>

            {/* Photography and Media */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Camera className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">6. Photography, Filming, and Media</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  BRT and its appointed media partners may photograph, film, and record the event for marketing,{' '}
                  promotional, archival, and editorial purposes.
                </p>
                <p>
                  By attending a BRT event, you consent to being photographed or filmed and to BRT using such material{' '}
                  across its marketing channels, including social media, the website, print publications, and broadcast{' '}
                  media, without compensation or further notice to you.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    If you have specific concerns about being photographed or filmed, you must notify BRT in writing at{' '}
                    <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline"> info@thebrtsa.com</a> at least 48 hours before the event. BRT will make reasonable efforts to{' '}
                    accommodate your request but cannot guarantee that you will not appear in any event coverage.
                  </p>
                </div>
                <p>
                  BRT retains all intellectual property rights in event photographs, footage, and recordings. Attendees{' '}
                  may not sell, license, or commercially exploit any event content without BRT's prior written consent.
                </p>
              </div>
            </section>

            {/* Intellectual Property */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Eye className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">7. Intellectual Property</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  All content associated with BRT events - including but not limited to the BRT name, black carpet concept,{' '}
                  logo, branding, event materials, programme content, and design elements - is the intellectual property{' '}
                  of BRT or its licensors and is protected by applicable intellectual property laws.
                </p>
                <p>
                  You may not reproduce, distribute, publicly display, or create derivative works from any BRT intellectual{' '}
                  property without prior written permission from BRT.
                </p>
                <div className="p-4 bg-red-500/5 border border-red-500/10 rounded-xl mt-2">
                  <p className="text-xs text-red-400/60">
                    Unauthorised use of BRT's intellectual property may give rise to legal action.
                  </p>
                </div>
              </div>
            </section>

            {/* Liability */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">8. Liability</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">8.1 Personal Property</h3>
                  <p>
                    BRT is not responsible for the loss, theft, or damage of any personal property brought to or left at{' '}
                    the event venue. Attendees are advised to take reasonable care of their personal belongings throughout{' '}
                    the event.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">8.2 Personal Injury</h3>
                  <p>
                    BRT takes reasonable precautions to ensure the safety of all event attendees. However, to the fullest{' '}
                    extent permitted by applicable law, including the CPA where applicable, BRT is not liable for any{' '}
                    personal injury sustained at or in connection with the event, except where such injury is caused{' '}
                    directly by BRT's gross negligence or wilful misconduct.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">8.3 Programme Changes</h3>
                  <p>
                    BRT shall not be liable for any loss, disappointment, or inconvenience arising from changes to the{' '}
                    event programme, including alterations to speakers, panelists, entertainment, or the running order,{' '}
                    provided the event takes place as substantially planned.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">8.4 Force Majeure</h3>
                  <p>
                    BRT shall not be liable for any failure or delay in hosting the event where such failure or delay{' '}
                    arises from circumstances beyond BRT's reasonable control, including acts of God, natural disasters,{' '}
                    pandemic or epidemic, civil unrest, government action, power outages, or any other event that could{' '}
                    not reasonably have been anticipated or prevented.
                  </p>
                  <p className="mt-1">
                    In such circumstances, BRT will use reasonable endeavours to reschedule the event and will{' '}
                    communicate with affected ticket holders as promptly as possible.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">8.5 General Limitation</h3>
                  <p>
                    To the fullest extent permitted by South African law, BRT's total liability to any attendee for any{' '}
                    claim arising from or in connection with these Terms shall not exceed the ticket price paid by that{' '}
                    attendee for the relevant event.
                  </p>
                </div>
              </div>
            </section>

            {/* Dispute Resolution */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Gavel className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">10. Dispute Resolution</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  In the event of a dispute arising from or in connection with these Terms or your attendance at a BRT event,{' '}
                  the parties agree to first attempt resolution through good faith negotiation.
                </p>
                <p>
                  You should direct your dispute to BRT in writing at <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline">info@thebrtsa.com</a>, and BRT will respond within 14 business days.
                </p>
                <p>
                  If the dispute is not resolved through negotiation within 30 days of written notice, either party may{' '}
                  refer the matter to mediation before a mutually agreed mediator. The cost of mediation shall be shared{' '}
                  equally between the parties unless otherwise agreed.
                </p>
                <p>
                  If mediation fails or either party elects not to mediate, the dispute shall be resolved by binding{' '}
                  arbitration under the rules of the Arbitration Foundation of Southern Africa (AFSA), conducted in{' '}
                  English in South Africa. The decision of the arbitrator shall be final and binding on both parties.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    Nothing in this clause prevents either party from seeking urgent or interim relief from a competent{' '}
                    court where necessary to protect its rights.
                  </p>
                </div>
              </div>
            </section>

            {/* General Provisions */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Scale className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">11. General Provisions</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Governing Law</h3>
                  <p>
                    These Terms are governed by and construed in accordance with the laws of the Republic of South Africa,{' '}
                    including the Consumer Protection Act 68 of 2008, the Protection of Personal Information Act 4 of 2013,{' '}
                    the Electronic Communications and Transactions Act 25 of 2002, and all other applicable legislation.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Severability</h3>
                  <p>
                    If any provision of these Terms is found to be invalid, unlawful, or unenforceable, that provision{' '}
                    shall be severed and the remainder of the Terms shall continue in full force and effect.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Whole Agreement</h3>
                  <p>
                    These Terms, together with the Privacy Policy and any written correspondence confirming your ticket{' '}
                    purchase, constitute the entire agreement between you and BRT in respect of your attendance at a BRT event.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">No Waiver</h3>
                  <p>
                    BRT's failure to enforce any provision of these Terms shall not constitute a waiver of that provision{' '}
                    or of BRT's right to enforce it in the future.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Notices</h3>
                  <p>
                    All formal notices to BRT under these Terms must be submitted in writing to{' '}
                    <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline">info@thebrtsa.com</a>.
                  </p>
                  <p className="mt-1">
                    BRT may give notice to you via the email address provided at the time of ticket purchase or by{' '}
                    posting a notice on our website.
                  </p>
                </div>
              </div>
            </section>

            {/* Contact */}
<section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
  <div className="flex items-center gap-3 mb-4">
    <Mail className="w-5 h-5 text-[#C9A227]" />
    <h2 className="text-lg font-semibold text-white">12. Contact Us</h2>
  </div>

  <div className="space-y-3 text-sm text-white/60 leading-relaxed">
    <p>
      For any queries relating to these Terms and Conditions, please contact:
    </p>

    <div className="p-4 bg-white/5 rounded-xl space-y-1 mt-2">
      <p className="text-white/80">The Brt (Pty) Ltd</p>

      <p className="text-white/60">
        West Tower, 2nd Floor, Nelson Mandela Square
      </p>

      <p className="text-white/60">
        Maude Street
      </p>

      <p className="text-white/60">
        Sandown
      </p>

      <p className="text-white/60">
        Johannesburg, 2146
      </p>

      <p className="text-white/60">
        South Africa
      </p>

      <p className="text-white/60">
        Email:{" "}
        <a
          href="mailto:info@thebrtsa.com"
          className="text-[#C9A227] hover:underline"
        >
          info@thebrtsa.com
        </a>
      </p>

      <p className="text-white/60">
        Website:{" "}
        <a
          href="https://www.thebrtsa.com"
          target="_blank"
          rel="noopener noreferrer"
          className="text-[#C9A227] hover:underline"
        >
          www.thebrtsa.com
        </a>
      </p>
    </div>
  </div>
</section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TermsAndConditions;