// pages/PrivacyPolicy.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ChevronLeft, 
  Shield, 
  Mail, 
  Globe, 
  FileText, 
  Eye, 
  Info, 
  Lock,
  Cookie,
  Database,
  Users,
  Share2,
  Clock,
  AlertCircle,
  Scale
} from 'lucide-react';

function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-black text-white font-manrope">

      {/* Main Content */}
      <div className="pt-[62px]">
        <div className="max-w-[1400px] mx-auto px-6 py-16">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-16 h-16 rounded-2xl bg-[#C9A227]/10 flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-[#C9A227]" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
              Privacy Policy
            </h1>
            <p className="text-sm text-white/40">
              The Brt (Pty) Ltd Registration Number: 2026/382883/07
            </p>
            <p className="text-xs text-white/20 mt-1">
              Effective Date: 7 July 2026
            </p>
          </div>

          {/* Policy Content */}
          <div className="space-y-6">
            {/* Introduction */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Info className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">1. Introduction</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  The Brt (Pty) Ltd ("BRT", "we", "us", "our") is committed to protecting the privacy and personal{' '}
                  information of all individuals who interact with our website, platform, and services.
                </p>
                <p>
                  This Privacy Policy explains how we collect, use, store, and protect your personal information in{' '}
                  accordance with the <span className="text-white/80">Protection of Personal Information Act 4 of 2013 (POPIA)</span>{' '}
                  and all applicable South African legislation.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    By using our website or platform, you acknowledge that you have read and understood this Privacy Policy.
                  </p>
                </div>
              </div>
            </section>

            {/* Who We Are */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">2. Who We Are</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  BRT is a founder-investor matchmaking platform and event company headquartered in{' '}
                  <span className="text-white/80">Newcastle, KwaZulu-Natal, South Africa</span>.
                </p>
                <p>
                  We operate as an introducer, connecting founders with equity investors and credit providers, and{' '}
                  host the annual <span className="text-white/80">BRT Black Carpet Gala</span>.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    Our Information Officer is responsible for ensuring compliance with POPIA and can be contacted at{' '}
                    the details provided in Section 10.
                  </p>
                </div>
              </div>
            </section>

            {/* Information We Collect */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Database className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">3. Information We Collect</h2>
              </div>
              <div className="space-y-4 text-sm text-white/60 leading-relaxed">
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Identity Information</h3>
                  <p>Full name, title, identity number, and date of birth.</p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Contact Information</h3>
                  <p>Email address, phone number, and physical or postal address.</p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Professional Information</h3>
                  <p>
                    Company name, registration number, industry, job title, years in operation, and business financials{' '}
                    where relevant to our matching services.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Financial Information</h3>
                  <p>
                    Funding requirements, revenue figures, and investment mandates, collected solely for the purpose of{' '}
                    facilitating introductions between founders and capital providers.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Event Information</h3>
                  <p>
                    Dietary preferences, accessibility requirements, and attendance confirmations collected in relation{' '}
                    to BRT events.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Technical Information</h3>
                  <p>
                    IP address, browser type, device information, and cookies collected automatically when you visit{' '}
                    our website.
                  </p>
                </div>
                <div>
                  <h3 className="text-white/80 font-medium mb-1">Communications</h3>
                  <p>Records of correspondence between you and BRT via email, WhatsApp, or our platform.</p>
                </div>
              </div>
            </section>

            {/* How We Collect */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Users className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">4. How We Collect Your Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>We collect personal information:</p>
                <ul className="list-disc list-inside space-y-2 text-white/60 ml-4">
                  <li>
                    <span className="text-white/80">Directly from you</span> when you register on our platform, submit an{' '}
                    enquiry, purchase an event ticket, or correspond with us
                  </li>
                  <li>
                    <span className="text-white/80">From publicly available sources</span> such as company registries,{' '}
                    LinkedIn, and business directories
                  </li>
                  <li>
                    <span className="text-white/80">Through our website</span> via cookies and analytics tools
                  </li>
                  <li>
                    <span className="text-white/80">From third parties</span> such as payment processors and event{' '}
                    ticketing platforms
                  </li>
                </ul>
              </div>
            </section>

            {/* Why We Collect */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Eye className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">5. Why We Collect Your Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>We process your personal information for the following lawful purposes:</p>
                <ul className="list-disc list-inside space-y-2 text-white/60 ml-4">
                  <li>To facilitate introductions between founders, investors, and credit providers</li>
                  <li>To manage event registrations, ticketing, and attendance</li>
                  <li>To communicate with you about BRT services, events, and updates</li>
                  <li>To process payments and maintain financial records</li>
                  <li>To improve our platform and website experience</li>
                  <li>To comply with our legal and regulatory obligations</li>
                  <li>To verify your identity and professional credentials where relevant</li>
                </ul>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    We will not process your personal information for any purpose incompatible with those listed above{' '}
                    without your prior consent.
                  </p>
                </div>
              </div>
            </section>

            {/* Sharing Your Information */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Share2 className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">6. Sharing Your Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <div className="p-4 bg-[#C9A227]/5 border border-[#C9A227]/10 rounded-xl mb-3">
                  <p className="text-xs text-white/60">
                    <span className="text-white/80 font-medium">BRT does not sell your personal information to third parties.</span>
                  </p>
                </div>
                <p>We may share your information with:</p>
                <ul className="list-disc list-inside space-y-2 text-white/60 ml-4">
                  <li>
                    <span className="text-white/80">Investors and Lenders</span> - where you have registered as a founder{' '}
                    seeking capital and have consented to your profile being shared for matching purposes
                  </li>
                  <li>
                    <span className="text-white/80">Founders</span> - where you have registered as an investor or lender{' '}
                    and have consented to receiving founder profiles
                  </li>
                  <li>
                    <span className="text-white/80">Service Providers</span> - including payment processors, event{' '}
                    management platforms, and IT service providers who process information on our behalf under strict{' '}
                    confidentiality obligations
                  </li>
                  <li>
                    <span className="text-white/80">Legal and Regulatory Authorities</span> - where we are required to do so by law
                  </li>
                </ul>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    All third parties with whom we share your information are required to handle it in accordance with{' '}
                    POPIA and applicable data protection standards.
                  </p>
                </div>
              </div>
            </section>

            {/* Cookies */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Cookie className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">7. Cookies</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  Our website uses cookies to enhance your browsing experience and collect anonymised usage data. You may{' '}
                  disable cookies through your browser settings, however this may affect the functionality of certain{' '}
                  features on our website.
                </p>
                <p>We use the following types of cookies:</p>
                <ul className="list-disc list-inside space-y-2 text-white/60 ml-4">
                  <li>
                    <span className="text-white/80">Essential cookies</span> - necessary for the website to function
                  </li>
                  <li>
                    <span className="text-white/80">Analytics cookies</span> - to understand how visitors use our website
                  </li>
                  <li>
                    <span className="text-white/80">Preference cookies</span> - to remember your settings and preferences
                  </li>
                </ul>
              </div>
            </section>

            {/* How We Protect */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Lock className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">8. How We Protect Your Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  BRT implements appropriate technical and organisational measures to protect your personal information{' '}
                  against unauthorised access, loss, destruction, or disclosure. These include secure servers, encrypted{' '}
                  data transmission, access controls, and regular security reviews.
                </p>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    While we take all reasonable precautions, no method of electronic transmission or storage is completely{' '}
                    secure. We encourage you to exercise caution when sharing sensitive information online.
                  </p>
                </div>
              </div>
            </section>

            {/* Retention */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Clock className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">9. Retention of Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  We retain your personal information for as long as is necessary to fulfil the purposes for which it was{' '}
                  collected, or as required by law. When your information is no longer required, it will be securely deleted{' '}
                  or anonymised.
                </p>
                <p>
                  Event-related information is typically retained for a period of <span className="text-white/80">five years</span>{' '}
                  for record-keeping purposes.
                </p>
                <p>
                  Platform registration data is retained for the duration of your active relationship with BRT and for a{' '}
                  reasonable period thereafter.
                </p>
              </div>
            </section>

            {/* Your Rights */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Scale className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">10. Your Rights</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>Under POPIA, you have the right to:</p>
                <ul className="list-disc list-inside space-y-2 text-white/60 ml-4">
                  <li>Be notified that your personal information is being collected</li>
                  <li>Access the personal information we hold about you</li>
                  <li>Request correction of inaccurate or outdated information</li>
                  <li>Request deletion of your personal information, subject to our legal obligations</li>
                  <li>Object to the processing of your personal information</li>
                  <li>Lodge a complaint with the Information Regulator of South Africa</li>
                </ul>
                <div className="p-4 bg-white/5 rounded-xl mt-2">
                  <p className="text-xs text-white/40">
                    To exercise any of these rights, please contact us at the details below.
                  </p>
                </div>
              </div>
            </section>

<section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
  <div className="flex items-center gap-3 mb-4">
    <Mail className="w-5 h-5 text-[#C9A227]" />
    <h2 className="text-lg font-semibold text-white">11. Contact Us</h2>
  </div>

  <div className="space-y-4 text-sm text-white/60 leading-relaxed">
    {/* Information Officer */}
    <div>
      <h3 className="text-white/80 font-medium mb-2">
        Information Officer
      </h3>

      <div className="p-4 bg-white/5 rounded-xl space-y-1">
        <p className="text-white/80">The Brt (Pty) Ltd</p>

        <p className="text-white/60">
          West Tower, 2nd Floor, Nelson Mandela Square
        </p>

        <p className="text-white/60">
          Maude Street
        </p>

        <p className="text-white/60">
          Sandown
        </p>

        <p className="text-white/60">
          Johannesburg, 2146
        </p>

        <p className="text-white/60">
          South Africa
        </p>

        <p className="text-white/60">
          Email:{" "}
          <a
            href="mailto:info@thebrtsa.com"
            className="text-[#C9A227] hover:underline"
          >
            info@thebrtsa.com
          </a>
        </p>

        <p className="text-white/60">
          Website:{" "}
          <a
            href="https://www.thebrtsa.com"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#C9A227] hover:underline"
          >
            www.thebrtsa.com
          </a>
        </p>
      </div>
    </div>

    {/* Information Regulator */}
    <div>
      <h3 className="text-white/80 font-medium mb-2">
        Information Regulator of South Africa
      </h3>

      <div className="p-4 bg-white/5 rounded-xl space-y-1">
        <p className="text-white/60">
          Website:{" "}
          <a
            href="https://www.inforegulator.org.za"
            target="_blank"
            rel="noopener noreferrer"
            className="text-[#C9A227] hover:underline"
          >
            www.inforegulator.org.za
          </a>
        </p>

        <p className="text-white/60">
          Email:{" "}
          <a
            href="mailto:inforeg@justice.gov.za"
            className="text-[#C9A227] hover:underline"
          >
            inforeg@justice.gov.za
          </a>
        </p>
      </div>
    </div>
  </div>
</section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default PrivacyPolicy;