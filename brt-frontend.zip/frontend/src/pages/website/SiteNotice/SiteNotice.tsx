// pages/SiteNotice.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeft, Building2, Mail, Globe, Calendar, FileText, Shield, AlertCircle, Scale, BookOpen, Eye } from 'lucide-react';

function SiteNotice() {
  return (
    <div className="min-h-screen bg-black text-white font-manrope">

      {/* Main Content */}
      <div className="pt-[62px]">
        <div className="max-w-[1400px] mx-auto px-6 py-16">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="w-16 h-16 rounded-2xl bg-[#C9A227]/10 flex items-center justify-center mx-auto mb-4">
              <FileText className="w-8 h-8 text-[#C9A227]" />
            </div>
            <h1 className="text-3xl md:text-4xl font-bold text-white mb-3">
              Site Notice
            </h1>
            <p className="text-sm text-white/40">
              The Brt (Pty) Ltd Registration Number: 2026/382883/07
            </p>
            <p className="text-xs text-white/20 mt-1">
              Effective Date: 7 July 2026
            </p>
          </div>

          {/* Notice Content */}
          <div className="space-y-6">
            {/* Company Information */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Building2 className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">1. Company Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  This website, <span className="text-white/80">www.thebrtsa.com</span>, is owned and operated by{' '}
                  <span className="text-white/80">The Brt (Pty) Ltd</span>, a private company duly registered in{' '}
                  accordance with the Companies Act 71 of 2008 of the Republic of South Africa.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 p-4 bg-white/5 rounded-xl">
                  <div>
                    <p className="text-xs text-white/30">Legal Name</p>
                    <p className="text-sm text-white/80">The Brt (Pty) Ltd</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Registration Number</p>
                    <p className="text-sm text-white/80">2026/382883/07</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Country of Incorporation</p>
                    <p className="text-sm text-white/80">Republic of South Africa</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Registered Address</p>
                    <p className="text-sm text-white/80">
                      West Tower, 2nd Floor, Nelson Mandela Square
                      <br />
                      Maude Street
                      <br />
                      Sandown
                      <br />
                      Johannesburg
                      <br />
                      2146
                      <br />
                      South Africa
                    </p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Website</p>
                    <p className="text-sm text-white/80">www.thebrtsa.com</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Email</p>
                    <p className="text-sm text-white/80">info@thebrtsa.com</p>
                  </div>
                </div>
              </div>
            </section>

            {/* Nature of Business */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Calendar className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">2. Nature of Business</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  The Brt (Pty) Ltd trades as <span className="text-white/80">The Black Roundtable ("BRT")</span> and{' '}
                  operates as a premium event company. BRT's flagship offering is the{' '}
                  <span className="text-white/80">BRT Black Carpet Gala</span> - an annual black-tie event held in{' '}
                  KwaZulu-Natal that brings together founders, investors, executives, and senior professionals for an{' '}
                  evening of curated networking, keynote addresses, and thought leadership.
                </p>
              </div>
            </section>

            {/* Website Purpose */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Globe className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">3. Website Purpose</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  This website is operated for the purpose of providing information about BRT and its events,{' '}
                  facilitating ticket purchases, and enabling communication between BRT and its guests, partners,{' '}
                  and the public. Nothing on this website constitutes financial, legal, investment, or professional{' '}
                  advice of any kind.
                </p>
              </div>
            </section>

            {/* Applicable Law */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Scale className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">4. Applicable Law and Jurisdiction</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  This website is hosted and operated from the Republic of South Africa. All use of this website{' '}
                  and any dispute arising therefrom is governed by the laws of the Republic of South Africa,{' '}
                  including but not limited to:
                </p>
                <ul className="list-disc list-inside space-y-1 text-white/60 ml-4">
                  <li>The Electronic Communications and Transactions Act 25 of 2002 ("ECT Act")</li>
                  <li>The Protection of Personal Information Act 4 of 2013 ("POPIA")</li>
                  <li>The Consumer Protection Act 68 of 2008 ("CPA")</li>
                  <li>The Companies Act 71 of 2008</li>
                </ul>
                <p className="mt-2">
                  Users who access this website from outside South Africa do so at their own initiative and are{' '}
                  responsible for compliance with their local laws to the extent applicable.
                </p>
              </div>
            </section>

            {/* ECT Act Compliance */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <BookOpen className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">5. Compliance with the ECT Act</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  In accordance with Section 43 of the Electronic Communications and Transactions Act 25 of 2002,{' '}
                  the following information is disclosed:
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-4 p-4 bg-white/5 rounded-xl">
                  <div>
                    <p className="text-xs text-white/30">Full legal name</p>
                    <p className="text-sm text-white/80">The Brt (Pty) Ltd</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Registration number</p>
                    <p className="text-sm text-white/80">2026/382883/07</p>
                  </div>
                  <div>
                    <p className="text-xs text-white/30">Physical address</p>
                    <p className="text-sm text-white/80">
                      West Tower, 2nd Floor, Nelson Mandela Square
                      <br />
                      Maude Street
                      <br />
                      Sandown
                      <br />
                      Johannesburg
                      <br />
                      2146
                      <br />
                      South Africa
                    </p>
                  </div>

                  <div>
                    <p className="text-xs text-white/30">Website address</p>
                    <p className="text-sm text-white/80">www.thebrtsa.com</p>
                  </div>
                  <div className="md:col-span-2">
                    <p className="text-xs text-white/30">Email address</p>
                    <p className="text-sm text-white/80">info@thebrtsa.com</p>
                  </div>
                </div>
                <p className="mt-2">
                  Users are entitled to request the following information from BRT at any time, and BRT undertakes{' '}
                  to provide it upon written request:
                </p>
                <ul className="list-disc list-inside space-y-1 text-white/60 ml-4">
                  <li>The physical address at which BRT can receive legal service of documents</li>
                  <li>The names of BRT's directors</li>
                  <li>The VAT registration number of BRT, where applicable</li>
                </ul>
                <p className="mt-2">
                  Requests may be directed to <span className="text-white/80">info@thebrtsa.com</span>.
                </p>
              </div>
            </section>

            {/* Privacy & POPIA */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">6. Privacy and Personal Information</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  The Brt (Pty) Ltd is committed to the protection of your personal information in accordance with POPIA.{' '}
                  The manner in which we collect, use, store, and protect your personal information is set out in our{' '}
                  Privacy Policy, which is available on this website at <span className="text-white/80">www.thebrtsa.com</span>.
                </p>
                <p>
                  By using this website, you acknowledge that you have read and understood our Privacy Policy and{' '}
                  consent to the processing of your personal information as described therein.
                </p>
              </div>
            </section>

            {/* Intellectual Property */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Eye className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">8. Intellectual Property</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  All content on this website - including but not limited to text, graphics, photographs, logos,{' '}
                  the BRT name, the black carpet concept, event materials, and design elements - is the intellectual{' '}
                  property of The Brt (Pty) Ltd or its licensors and is protected by applicable intellectual property laws.
                </p>
                <p>
                  No content on this website may be reproduced, distributed, modified, transmitted, republished,{' '}
                  or used in any form without the prior written permission of The Brt (Pty) Ltd.
                </p>
                <p>
                  Unauthorised use of any content on this website may give rise to a claim for damages and other{' '}
                  legal remedies.
                </p>
              </div>
            </section>

            {/* Disclaimer */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <AlertCircle className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">9. Disclaimer</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  The information published on this website is provided for general informational purposes only.{' '}
                  While BRT takes reasonable steps to ensure that the information on this website is accurate and{' '}
                  up to date, BRT makes no representations or warranties of any kind, express or implied, regarding{' '}
                  the completeness, accuracy, reliability, or suitability of the information contained herein.
                </p>
                <p>
                  BRT reserves the right to update, amend, or remove any content on this website at any time without{' '}
                  prior notice. Nothing on this website constitutes an offer, invitation to purchase, or contractual{' '}
                  commitment unless expressly stated otherwise.
                </p>
                <p>
                  Ticket purchases are governed by BRT's Terms and Conditions, available at{' '}
                  <span className="text-white/80">www.thebrtsa.com</span>.
                </p>
              </div>
            </section>

            {/* Limitation of Liability */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Shield className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">11. Limitation of Liability</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  To the fullest extent permitted by applicable South African law, The Brt (Pty) Ltd shall not be{' '}
                  liable for any direct, indirect, incidental, consequential, or punitive damages arising from your{' '}
                  use of or inability to use this website, including any errors or omissions in the content,{' '}
                  technical interruptions, or unauthorised access to our systems.
                </p>
                <p>
                  This limitation applies regardless of whether such damages were foreseeable or whether BRT had{' '}
                  been advised of the possibility of such damages.
                </p>
              </div>
            </section>

            {/* Contact */}
            <section className="bg-[#0E0909] border border-white/5 rounded-2xl p-6 md:p-8">
              <div className="flex items-center gap-3 mb-4">
                <Mail className="w-5 h-5 text-[#C9A227]" />
                <h2 className="text-lg font-semibold text-white">13. Contact Us</h2>
              </div>
              <div className="space-y-3 text-sm text-white/60 leading-relaxed">
                <p>
                  For any queries relating to this Site Notice or the operation of this website, please contact:
                </p>
                <div className="p-4 bg-white/5 rounded-xl space-y-1 mt-2">
                  <p className="text-white/80">The Brt (Pty) Ltd</p>
                  <p className="text-white/60">Newcastle, KwaZulu-Natal, South Africa</p>
                  <p className="text-white/60">
                    Email: <a href="mailto:info@thebrtsa.com" className="text-[#C9A227] hover:underline">info@thebrtsa.com</a>
                  </p>
                  <p className="text-white/60">
                    Website: <a href="https://www.thebrtsa.com" target="_blank" rel="noopener noreferrer" className="text-[#C9A227] hover:underline">www.thebrtsa.com</a>
                  </p>
                </div>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
}

export default SiteNotice;