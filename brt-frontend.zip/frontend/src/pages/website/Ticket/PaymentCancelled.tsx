// components/auth/PaymentCancelled.tsx
import React, { useEffect, useState } from "react";
import { XCircle, Home, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";

const PaymentCancelled: React.FC = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  useEffect(() => {
    const cancelTicket = async () => {
      // Check if we have a pending ticket ID in session
      const ticketId = sessionStorage.getItem('pendingTicketId');
      const hasPendingPayment = sessionStorage.getItem('pendingPayment');

      if (!ticketId || !hasPendingPayment) {
        console.log('No pending ticket found in session');
        return;
      }

      try {
        setIsLoading(true);
        setError(null);

        // Simple API call - only ticket ID in URL
        const response = await fetch(
          `${import.meta.env.VITE_API_URL}/api/tickets/${ticketId}/cancel`,
          {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            }
            // No body needed - backend handles everything
          }
        );

        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to cancel ticket');
        }

        const data = await response.json();
        console.log('✅ Ticket cancelled:', data);
        
        setSuccess(true);

        // Clear session storage
        sessionStorage.removeItem('pendingTicketId');
        sessionStorage.removeItem('pendingPayment');

      } catch (err) {
        console.error('❌ Error cancelling ticket:', err);
        setError(err instanceof Error ? err.message : 'Failed to cancel ticket');
      } finally {
        setIsLoading(false);
      }
    };

    cancelTicket();
  }, []);

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/80 px-4">
      <div className="w-full max-w-md rounded-2xl p-8 text-center bg-[#111] border border-red-500/30">
        {/* Icon */}
        <div className="flex justify-center mb-6">
          <div className={`w-20 h-20 rounded-full flex items-center justify-center ${
            isLoading ? 'bg-yellow-500/20' : 
            success ? 'bg-green-500/20' : 
            'bg-red-500/20'
          }`}>
            {isLoading ? (
              <Loader2 className="w-12 h-12 text-yellow-500 animate-spin" />
            ) : (
              <XCircle className={`w-12 h-12 ${success ? 'text-green-500' : 'text-red-500'}`} />
            )}
          </div>
        </div>

        {/* Content */}
        <h2 className="text-2xl font-bold text-white mb-2">
          {isLoading ? 'Processing...' : success ? 'Ticket Cancelled' : 'Payment Cancelled'}
        </h2>

        <p className="text-white/60 mb-8">
          {isLoading 
            ? 'Please wait while we cancel your ticket...' 
            : error 
              ? error 
              : success
                ? 'Your ticket has been cancelled successfully.'
                : 'Your payment was cancelled and no ticket has been generated.'}
        </p>

        {/* Home Button */}
        <Link
          to="/"
          className="inline-flex items-center justify-center gap-2 w-full px-6 py-3 rounded-xl bg-[#C9A227] text-black font-semibold hover:opacity-90 transition"
          onClick={() => {
            sessionStorage.removeItem('pendingTicketId');
            sessionStorage.removeItem('pendingPayment');
          }}
        >
          <Home className="w-5 h-5" />
          Back to Home
        </Link>
      </div>
    </div>
  );
};

export default PaymentCancelled;