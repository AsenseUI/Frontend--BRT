// pages/TicketPage.tsx
import React, { useEffect, useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { ChevronLeft, Loader2, AlertCircle, Home } from 'lucide-react';
import Logo from '@/assets/home/logo.webp';
import TicketStep from '@/components/auth/TicketStep';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

interface FullTicketData {
  _id: string;
  ticketId: string;
  generatedTicketNumber: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  selectedPlan: string;
  paymentMethod: string;
  paymentStatus: string;
  amountPaid: number;
  totalAmount: number;
  outstandingBalance: number;
  transactionId: string;
  eventName: string;
  eventDate: string;
  status: string;
}

const Ticket = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
  });
  const [selectedPlan, setSelectedPlan] = useState<'full' | 'partial' | null>(null);
  const [ticketId, setTicketId] = useState<string>('');
  const [fullTicketData, setFullTicketData] = useState<FullTicketData | null>(null);

  // ✅ Get ticket reference from URL or session storage
  const getTicketReference = () => {
    // 1. Check URL params first (for direct links)
    const urlRef = searchParams.get('ref') || searchParams.get('ticketId');
    if (urlRef) {
      return urlRef;
    }

    // 2. Check session storage (for payment returns)
    const pendingTicketId = sessionStorage.getItem('pendingTicketId');
    const isPendingPayment = sessionStorage.getItem('pendingPayment') === 'true';

    if (pendingTicketId && isPendingPayment) {
      // Clear session storage to prevent showing old data on refresh
      sessionStorage.removeItem('pendingTicketId');
      sessionStorage.removeItem('pendingPayment');

      // ✅ Update URL to include ticketId (for bookmarking)
      window.history.replaceState({}, '', `/ticket?ticketId=${pendingTicketId}`);

      return pendingTicketId;
    }

    return null;
  };

  const fetchTicket = async (ref: string) => {
    try {
      const response = await fetch(`${API_BASE_URL}/api/payments/tickets/${ref}`);
      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || 'Failed to fetch ticket');
      }

      const data = result.data;
      setFormData({
        firstName: data.firstName || '',
        lastName: data.lastName || '',
        email: data.email || '',
        phone: data.phoneNumber || '',
      });
      setSelectedPlan(data.selectedPlan || null);
      setTicketId(data.ticketId || ref);

      setFullTicketData({
        _id: data._id || '',
        ticketId: data.ticketId || ref,
        generatedTicketNumber: data.generatedTicketNumber || ref,
        firstName: data.firstName || '',
        lastName: data.lastName || '',
        email: data.email || '',
        phoneNumber: data.phoneNumber || '',
        selectedPlan: data.selectedPlan || 'full',
        paymentMethod: data.paymentMethod || '',
        paymentStatus: data.paymentStatus || '',
        amountPaid: data.amountPaid ?? 0,
        totalAmount: data.totalAmount ?? 0,
        outstandingBalance: data.outstandingBalance ?? 0,
        transactionId: data.transactionId || '',
        eventName: data.eventName || 'BRT 150 - Black Carpet Gala',
        eventDate: data.eventDate || '',
        status: data.status || 'confirmed',
      });

      setLoading(false);

    } catch (err) {
      console.error('Error fetching ticket:', err);
      setError(err instanceof Error ? err.message : 'Failed to fetch ticket');
      setLoading(false);
    }
  };

  useEffect(() => {
    const ticketRef = getTicketReference();

    if (!ticketRef) {
      // ✅ If no ticket reference found, check if we're returning from payment
      // and the ticket was just created
      const justPaid = sessionStorage.getItem('justPaid');
      if (justPaid === 'true') {
        sessionStorage.removeItem('justPaid');
        // Show a message or redirect to home
        setError('Payment completed! Please check your email for ticket details.');
        setLoading(false);
        return;
      }

      setError('No ticket reference found');
      setLoading(false);
      return;
    }

    fetchTicket(ticketRef);
  }, []);

  // pages/TicketPage.tsx
  // Replace the entire return statement with:

  if (loading) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-12 h-12 animate-spin text-[#C9A227]" />
          <p className="text-white/40 text-sm">Loading your ticket...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-[#050505] flex items-center justify-center px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-red-500/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-red-400" />
          </div>
          <h2 className="text-2xl font-bold text-white mb-2">Something went wrong</h2>
          <p className="text-white/40 text-sm mb-6">{error}</p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={() => navigate('/')}
              className="px-6 py-2.5 bg-[#C9A227] text-[#050505] rounded-lg hover:bg-[#DFBA3A] transition-colors font-medium flex items-center gap-2"
            >
              <Home className="w-4 h-4" />
              Go Home
            </button>
            <button
              onClick={() => window.location.reload()}
              className="px-6 py-2.5 border border-white/10 text-white/60 rounded-lg hover:bg-white/5 transition-colors font-medium"
            >
              Try Again
            </button>
          </div>
        </div>
      </div>
    );
  }

  // Success - Show Ticket (directly render the overlay)
  return (
    <TicketStep
      formData={formData}
      selectedPlan={selectedPlan}
      ticketData={fullTicketData || undefined}
      onClose={() => navigate('/')}
    />
  );
};

export default Ticket;