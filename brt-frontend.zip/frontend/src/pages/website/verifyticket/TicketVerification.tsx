// src/pages/TicketVerification.tsx
import React, { useState, useEffect } from "react";
import { useSearchParams, Link } from "react-router-dom";
import { 
  CheckCircle, 
  XCircle, 
  Loader2, 
  User, 
  Mail, 
  Phone, 
  Calendar, 
  Tag,
  ArrowLeft,
  CreditCard
} from "lucide-react";

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

interface TicketData {
  ticketId: string;
  fullName: string;
  email: string;
  phoneNumber: string;
  eventName: string;
  eventDate: string;
  status: string;
  amountPaid: number;
  paymentStatus: string;
}

const TicketVerification = () => {
  const [searchParams] = useSearchParams();
  const ticketId = searchParams.get('ticketId');
  
  const [loading, setLoading] = useState(true);
  const [ticketData, setTicketData] = useState<TicketData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [valid, setValid] = useState(false);

  useEffect(() => {
    if (ticketId) {
      verifyTicket();
    } else {
      setError('No ticket ID provided');
      setLoading(false);
    }
  }, [ticketId]);

  const verifyTicket = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await fetch(`${API_BASE_URL}/api/tickets/verify/${ticketId}`);
      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || 'Ticket not found');
      }

      setTicketData(result.data);
      setValid(result.valid);
      
    } catch (error) {
      console.error('Error verifying ticket:', error);
      setError(error instanceof Error ? error.message : 'Failed to verify ticket');
      setValid(false);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    if (!dateString) return 'N/A';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-ZA', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
  };

  const formatCurrency = (amount: number) => {
    return `R${amount.toLocaleString('en-ZA')}`;
  };

  // Loading State
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505]">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-10 h-10 animate-spin text-[#C9A227]" />
          <p className="text-white/40 text-sm">Verifying ticket...</p>
        </div>
      </div>
    );
  }

  // Error State
  if (error || !ticketId) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#050505] p-4">
        <div className="max-w-sm w-full bg-[#0E0909] border border-red-500/20 rounded-xl p-6 text-center">
          <XCircle className="w-14 h-14 text-red-500 mx-auto mb-3" />
          <h2 className="text-lg font-bold text-white mb-1">Invalid Ticket</h2>
          <p className="text-white/40 text-sm mb-5">{error || 'No ticket ID provided'}</p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-4 py-2 text-sm text-[#C9A227] border border-[#C9A227]/30 rounded-lg hover:bg-[#C9A227]/10 transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#050505] p-3 flex items-center justify-center">
      <div className="max-w-sm w-full max-h-[95vh] overflow-y-auto custom-scrollbar my-[60px]">
        {/* Ticket Verification Card */}
        <div className="bg-[#0E0909] border rounded-xl overflow-hidden">
          {/* Header - Smaller */}
          <div className={`p-4 text-center border-b ${
            valid 
              ? 'border-green-500/20 bg-green-500/5' 
              : 'border-red-500/20 bg-red-500/5'
          }`}>
            {valid ? (
              <>
                <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-2" />
                <h2 className="text-xl font-bold text-white">✓ Valid Ticket</h2>
                <p className="text-green-400 text-xs mt-0.5">This ticket is valid and confirmed</p>
              </>
            ) : (
              <>
                <XCircle className="w-12 h-12 text-red-500 mx-auto mb-2" />
                <h2 className="text-xl font-bold text-white">✗ Invalid Ticket</h2>
                <p className="text-red-400 text-xs mt-0.5">This ticket is not valid</p>
              </>
            )}
          </div>

          {valid && ticketData && (
            <>
              {/* Ticket Details - Compact */}
              <div className="p-4 space-y-3">
                {/* Ticket ID */}
                <div className="bg-[#050505] rounded-lg p-3 border border-[#C9A227]/20">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <Tag className="w-3.5 h-3.5 text-[#C9A227]" />
                      <span className="text-[10px] text-white/40">Ticket ID</span>
                    </div>
                    <span className="text-xs font-bold text-[#C9A227] font-mono">
                      {ticketData.ticketId}
                    </span>
                  </div>
                </div>

                {/* Attendee Info - Compact Grid */}
                <div className="grid grid-cols-1 gap-2">
                  <div className="flex items-center gap-2.5 p-2.5 bg-[#050505] rounded-lg">
                    <User className="w-3.5 h-3.5 text-white/30" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-white/40">Attendee</p>
                      <p className="text-xs font-medium text-white truncate">{ticketData.fullName}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 p-2.5 bg-[#050505] rounded-lg">
                    <Mail className="w-3.5 h-3.5 text-white/30" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-white/40">Email</p>
                      <p className="text-xs font-medium text-white truncate">{ticketData.email}</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2.5 p-2.5 bg-[#050505] rounded-lg">
                    <Phone className="w-3.5 h-3.5 text-white/30" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-white/40">Phone</p>
                      <p className="text-xs font-medium text-white">{ticketData.phoneNumber}</p>
                    </div>
                  </div>
                </div>

                {/* Event Details - Compact */}
                <div className="bg-[#050505] rounded-lg p-3 space-y-1.5">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 text-[#C9A227]" />
                    <div className="flex-1 min-w-0">
                      <p className="text-[10px] text-white/40">Event</p>
                      <p className="text-xs font-medium text-white truncate">{ticketData.eventName}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 pl-5">
                    <p className="text-[10px] text-white/40">Date:</p>
                    <p className="text-xs font-medium text-white">{formatDate(ticketData.eventDate)}</p>
                  </div>
                </div>

                {/* Payment Details - Compact */}
                <div className="bg-[#050505] rounded-lg p-3">
                  <div className="flex items-center gap-2 mb-1.5">
                    <CreditCard className="w-3.5 h-3.5 text-[#C9A227]" />
                    <p className="text-[10px] text-white/40">Payment</p>
                  </div>
                  <div className="flex justify-between items-center pl-5">
                    <span className="text-[10px] text-white/60">Amount</span>
                    <span className="text-xs font-bold text-[#C9A227]">
                      {formatCurrency(ticketData.amountPaid)}
                    </span>
                  </div>
                  <div className="flex justify-between items-center pl-5 mt-0.5">
                    <span className="text-[10px] text-white/60">Status</span>
                    <span className={`text-[10px] font-medium ${
                      ticketData.paymentStatus === 'completed' || ticketData.paymentStatus === 'paid'
                        ? 'text-green-400'
                        : 'text-orange-400'
                    }`}>
                      {ticketData.paymentStatus === 'completed' || ticketData.paymentStatus === 'paid'
                        ? '✓ Paid in Full'
                        : '⏳ Partial Payment'
                      }
                    </span>
                  </div>
                </div>
              </div>

              {/* Footer - Smaller */}
              <div className="p-3 border-t border-white/5 text-center bg-[#050505]/50">
                <p className="text-[9px] text-white/20">
                  Presented by BRT 150 - Black Carpet Gala
                </p>
                <p className="text-[8px] text-white/10 mt-0.5">
                  Verified at: {new Date().toLocaleString()}
                </p>
              </div>
            </>
          )}

          {/* Invalid ticket - show minimal info */}
          {!valid && ticketData && (
            <div className="p-6 text-center">
              <p className="text-white/40 text-sm">
                This ticket could not be verified. Please contact support.
              </p>
            </div>
          )}
        </div>

        {/* Back Button - Smaller */}
        <div className="mt-3 text-center">
          <Link
            to="/"
            className="inline-flex items-center gap-1.5 text-xs text-white/30 hover:text-white/60 transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default TicketVerification;