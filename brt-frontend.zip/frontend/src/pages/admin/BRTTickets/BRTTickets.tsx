// pages/admin/BRTTickets.tsx
import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { 
  Search, 
  Eye, 
  Send,
  Funnel,
  Loader2,
  CheckCircle,
  XCircle,
  Clock,
  RefreshCw
} from "lucide-react";

interface Ticket {
  _id: string;
  ticketId: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  selectedRole: string;
  selectedPlan: string;
  paymentMethod: string;
  paymentStatus: string;
  amountPaid: number;
  totalAmount: number;
  outstandingBalance: number;
  transactionId: string;
  eventName: string;
  eventDate: string;
  status: string;
  submittedAt: string;
  contactMethod?: string;
  contactValue?: string;
  companyName?: string;
  businessUrl?: string;
  linkedInUrl?: string;
  projectDescription?: string;
  createdAt?: string;
  updatedAt?: string;
  partialWorkflowStatus?: string | null;
  depositAmount?: number | null;
  paymentLink?: string | null;
  generatedTicketNumber?: string | null;
}


interface ApiResponse {
  success: boolean;
  message: string;
  data: {
    totalTickets: number;
    fullPaymentCount: number;
    partialPaymentCount: number;
    tickets: Ticket[];
  };
}

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:5000/api';

const BRTTickets = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState("");
  const [filterPayment, setFilterPayment] = useState("All");
  const [filterStatus, setFilterStatus] = useState("All");
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [sendingLinkFor, setSendingLinkFor] = useState<string | null>(null);
  const [updatingStatusFor, setUpdatingStatusFor] = useState<string | null>(null);

  // Stats
  const [stats, setStats] = useState({
    totalApplications: 0,
    fullPayment: 0,
    partialPayment: 0,
    totalCollected: 0,
    totalOutstanding: 0,
  });

  // Status options for dropdown
  const statusOptions = [
    { value: "All", label: "All Statuses" },
    { value: "pending", label: "Pending" },
    { value: "approved", label: "Approved" },
    { value: "rejected", label: "Rejected" },
    { value: "cancelled", label: "Cancelled" }
  ];

  useEffect(() => {
    fetchTickets();
  }, []);

  const fetchTickets = async () => {
    setLoading(true);
    setError(null);
    try {
      const token = localStorage.getItem("token");

      const response = await fetch(`${API_BASE_URL}/api/admin/tickets`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch tickets');
      }
      
      const result: ApiResponse = await response.json();
      
      if (result.success && result.data) {
        const ticketList = result.data.tickets || [];
        setTickets(ticketList);
        
        setStats({
          totalApplications: result.data.totalTickets || ticketList.length,
          fullPayment: result.data.fullPaymentCount || 0,
          partialPayment: result.data.partialPaymentCount || 0,
          totalCollected: ticketList.reduce((sum, t) => sum + (t.amountPaid || 0), 0),
          totalOutstanding: ticketList.reduce((sum, t) => sum + (t.outstandingBalance || 0), 0),
        });
      } else {
        throw new Error(result.message || 'Failed to fetch tickets');
      }
    } catch (error) {
      console.error('Error fetching tickets:', error);
      setError(error instanceof Error ? error.message : 'Failed to load tickets');
    } finally {
      setLoading(false);
    }
  };

  // ✅ UPDATE TICKET STATUS
  const handleUpdateStatus = async (ticket: Ticket, newStatus: string) => {
    // if (!confirm(`Change status of ${ticket.firstName} ${ticket.lastName} to "${newStatus}"?`)) {
    //   return;
    // }

    setUpdatingStatusFor(ticket._id);
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `${API_BASE_URL}/api/admin/tickets/${ticket.ticketId}`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ status: newStatus }),
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || 'Failed to update status');
      }

      alert(`Ticket status updated to "${newStatus}" successfully!`);
      fetchTickets(); // Refresh the list
    } catch (error) {
      console.error('Error updating status:', error);
      alert(error instanceof Error ? error.message : 'Failed to update status. Please try again.');
    } finally {
      setUpdatingStatusFor(null);
    }
  };

  const getCategoryColor = (role: string) => {
    switch (role) {
      case "entrepreneur":
        return "text-blue-400 bg-blue-400/10 border-blue-400/30";
      case "investor":
        return "text-amber-400 bg-amber-400/10 border-amber-400/30";
      case "professional":
        return "text-purple-400 bg-purple-400/10 border-purple-400/30";
      default:
        return "text-white/40 bg-white/5 border-white/10";
    }
  };

  const getCategoryLabel = (role: string) => {
    switch (role) {
      case "entrepreneur": return "Entrepreneur";
      case "investor": return "Investor";
      case "professional": return "Professional";
      default: return role || "Unknown";
    }
  };

  const getPaymentColor = (paymentType: string) => {
    return paymentType === "full" 
      ? "text-green-400 bg-green-400/10 border-green-400/30"
      : "text-orange-400 bg-orange-400/10 border-orange-400/30";
  };

  const getPaymentLabel = (paymentType: string) => {
    return paymentType === "full" ? "Full Payment" : "Partial Payment";
  };

  const getStatusColor = (status: string) => {
    switch (status?.toLowerCase()) {
      case "approved":
        return "text-green-400 bg-green-400/10 border-green-400/30";
      case "pending":
        return "text-yellow-400 bg-yellow-400/10 border-yellow-400/30";
      case "rejected":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      case "cancelled":
        return "text-red-400 bg-red-400/10 border-red-400/30";
      default:
        return "text-white/40 bg-white/5 border-white/10";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status?.toLowerCase()) {
      case "approved":
        return <CheckCircle className="w-3 h-3 inline mr-1" />;
      case "pending":
        return <Clock className="w-3 h-3 inline mr-1" />;
      case "rejected":
      case "cancelled":
        return <XCircle className="w-3 h-3 inline mr-1" />;
      default:
        return null;
    }
  };

  const handleViewDetails = (mongoId: string) => {
    navigate(`/dashboard/brt-tickets/${mongoId}`);
  };

  const handleSendPaymentLink = async (ticket: Ticket) => {
    const paymentLink = window.prompt(
      `Paste the PayFast payment link for ${ticket.firstName} ${ticket.lastName} (${ticket.ticketId}):`
    );
    if (!paymentLink) return;

    const depositAmountStr = window.prompt(
      `Deposit amount for this link (R), out of R${ticket.totalAmount}:`,
      String(ticket.depositAmount ?? Math.round(ticket.totalAmount / 2))
    );
    if (!depositAmountStr) return;

    const depositAmount = Number(depositAmountStr);
    if (isNaN(depositAmount) || depositAmount <= 0) {
      alert("Please enter a valid deposit amount.");
      return;
    }

    setSendingLinkFor(ticket._id);
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(
        `${API_BASE_URL}/api/admin/partial-payments/${ticket.ticketId}/payment-link`,
        {
          method: 'PATCH',
          headers: {
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ paymentLink, depositAmount }),
        }
      );

      const result = await response.json();

      if (!response.ok || !result.success) {
        throw new Error(result.message || 'Failed to send payment link');
      }

      alert(result.message || 'Payment link sent successfully!');
      fetchTickets();
    } catch (error) {
      console.error('Error sending payment link:', error);
      alert(error instanceof Error ? error.message : 'Failed to send payment link. Please try again.');
    } finally {
      setSendingLinkFor(null);
    }
  };

  const filteredTickets = tickets.filter((ticket) => {
    const fullName = `${ticket.firstName || ''} ${ticket.lastName || ''}`.toLowerCase();
    const matchesSearch = 
      fullName.includes(searchTerm.toLowerCase()) ||
      (ticket.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (ticket.ticketId || '').toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesPaymentFilter = filterPayment === "All" || ticket.selectedPlan === filterPayment.toLowerCase().replace(" ", "");
    const matchesStatusFilter = filterStatus === "All" || ticket.status === filterStatus;
    
    return matchesSearch && matchesPaymentFilter && matchesStatusFilter;
  });

  const paymentFilters = ["All", "Full Payment", "Partial Payment"];

  const canSendPaymentLink = (ticket: Ticket) => {
    if (ticket.selectedPlan !== "partial") return false;
    const terminal = ["Fully Paid", "Ticket Issued", "approved", "cancelled", "rejected"];
    return !terminal.includes(ticket.partialWorkflowStatus || "") && ticket.status === "pending";
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-[#050505]">
        <div className="flex items-center gap-3 text-white/40">
          <Loader2 className="w-5 h-5 animate-spin" />
          Loading tickets...
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center bg-[#050505]">
        <div className="text-red-400 text-lg mb-3">Error loading tickets</div>
        <p className="text-white/40 mb-4">{error}</p>
        <button
          onClick={fetchTickets}
          className="px-4 py-2 text-sm text-[#C9A227] border border-[#C9A227]/30 rounded-lg hover:bg-[#C9A227]/10 transition-colors"
        >
          Retry
        </button>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-y-auto px-8 py-6 custom-scrollbar bg-[#050505]">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-1">BRT Tickets</h1>
        <p className="text-white/40">Review and manage ticket applications for BRT150 2026</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-5 gap-3 mb-8">
        <div className="bg-[#0E0909] border border-white/5 rounded-xl p-4">
          <p className="text-[11px] text-white/40 mb-1 leading-tight">Total Applications</p>
          <p className="text-xl font-bold text-white">{stats.totalApplications}</p>
        </div>
        <div className="bg-[#0E0909] border border-white/5 rounded-xl p-4">
          <p className="text-[11px] text-white/40 mb-1 leading-tight">Full Payment</p>
          <p className="text-xl font-bold text-green-400">{stats.fullPayment}</p>
        </div>
        <div className="bg-[#0E0909] border border-white/5 rounded-xl p-4">
          <p className="text-[11px] text-white/40 mb-1 leading-tight">Partial Payment</p>
          <p className="text-xl font-bold text-orange-400">{stats.partialPayment}</p>
        </div>
        <div className="bg-[#0E0909] border border-white/5 rounded-xl p-4">
          <p className="text-[11px] text-white/40 mb-1 leading-tight">Collected</p>
          <p className="text-xl font-bold text-[#C9A227]">R{stats.totalCollected.toLocaleString()}</p>
        </div>
        <div className="bg-[#0E0909] border border-white/5 rounded-xl p-4">
          <p className="text-[11px] text-white/40 mb-1 leading-tight">Outstanding</p>
          <p className="text-xl font-bold text-orange-400">R{stats.totalOutstanding.toLocaleString()}</p>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="flex flex-col sm:flex-row gap-3 mb-6 flex-wrap">
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-[18px] h-[18px] text-white/30" />
          <input
            type="text"
            placeholder="Search by name, email, or ticket ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-11 pr-4 py-2.5 bg-[#0A0707] border border-white/7 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#C9A227] text-white placeholder-white/30 text-sm"
          />
        </div>
        
        <div className="flex items-center gap-2 shrink-0 flex-wrap">
          <Funnel className="w-[15px] h-[15px] text-white/30" />
          {paymentFilters.map((filter) => (
            <button
              key={filter}
              onClick={() => setFilterPayment(filter)}
              className={`px-3 py-2 rounded-lg text-xs font-medium transition-colors border whitespace-nowrap ${
                filterPayment === filter
                  ? "bg-[#C9A227] text-[#050505] border-[#C9A227]"
                  : "bg-[#0A0707] border-white/7 text-white/40 hover:text-white"
              }`}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Status Filter Dropdown */}
        <div className="flex items-center gap-2 shrink-0">
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-3 py-2 bg-[#0A0707] border border-white/7 rounded-lg text-xs text-white/70 focus:outline-none focus:ring-2 focus:ring-[#C9A227]"
          >
            {statusOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Table */}
      <div className="bg-[#0E0909] border border-white/5 rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-white/5 border-b border-white/5">
              <tr>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Ticket ID</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Generated Ticket Number</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">First Name</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Last Name</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Email</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Phone</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Role</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Payment</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Status</th>
                <th className="px-5 py-3.5 text-left text-xs font-medium text-white/30 uppercase tracking-wide whitespace-nowrap">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredTickets.length === 0 ? (
                <tr>
                  <td colSpan={9} className="px-5 py-8 text-center text-white/30">
                    No tickets found
                  </td>
                </tr>
              ) : (
                filteredTickets.map((ticket) => (
                  <tr key={ticket._id} className="hover:bg-white/5 transition-colors">
                    <td className="px-5 py-4 font-mono text-xs text-white/30 whitespace-nowrap">{ticket.ticketId || 'N/A'}</td>
                    <td className="px-5 py-4 font-mono text-xs text-white/30 whitespace-nowrap">{ticket.generatedTicketNumber || 'N/A'}</td>
                    <td className="px-5 py-4 font-medium text-white whitespace-nowrap">{ticket.firstName || 'N/A'}</td>
                    <td className="px-5 py-4 font-medium text-white whitespace-nowrap">{ticket.lastName || 'N/A'}</td>
                    <td className="px-5 py-4 text-white/50 max-w-[150px] truncate">{ticket.email || 'N/A'}</td>
                    <td className="px-5 py-4 text-white/50 whitespace-nowrap">{ticket.phoneNumber || 'N/A'}</td>
                    <td className="px-5 py-4">
                      <span className={`text-xs px-2 py-1 rounded border whitespace-nowrap ${getCategoryColor(ticket.selectedRole)}`}>
                        {getCategoryLabel(ticket.selectedRole)}
                      </span>
                    </td>
                    <td className="px-5 py-4">
                      <div className="space-y-1">
                        <span className={`text-xs px-2 py-1 rounded border whitespace-nowrap ${getPaymentColor(ticket.selectedPlan)}`}>
                          {getPaymentLabel(ticket.selectedPlan)}
                        </span>
                        {ticket.selectedPlan === "partial" && (
                          <>
                            <div className="text-xs text-white/30">
                              <span className="text-green-400">R{ticket.amountPaid?.toLocaleString() || 0}</span>
                              <span className="mx-1">/</span>
                              <span>R{ticket.totalAmount?.toLocaleString() || 0}</span>
                            </div>
                            <div className="text-orange-400 text-xs mt-0.5">
                              Owes: R{ticket.outstandingBalance?.toLocaleString() || 0}
                            </div>
                            {ticket.partialWorkflowStatus && (
                              <div className="text-xs text-[#C9A227] mt-0.5">
                                {ticket.partialWorkflowStatus}
                              </div>
                            )}
                            {ticket.contactMethod && ticket.contactValue && (
                              <div className="text-xs text-white/30">
                                {ticket.contactMethod}: <span className="text-white">{ticket.contactValue}</span>
                              </div>
                            )}
                          </>
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-2">
                        <span className={`text-xs px-2 py-1 rounded border whitespace-nowrap ${getStatusColor(ticket.status)}`}>
                          {getStatusIcon(ticket.status)}
                          {ticket.status || 'Pending'}
                        </span>
                        
                        {/* Status Update Dropdown */}
                        <select
                          value={ticket.status || 'pending'}
                          onChange={(e) => handleUpdateStatus(ticket, e.target.value)}
                          disabled={updatingStatusFor === ticket._id}
                          className="text-[10px] px-1 py-0.5 bg-[#0A0707] border border-white/7 rounded text-white/50 focus:outline-none focus:ring-1 focus:ring-[#C9A227] disabled:opacity-40"
                        >
                          {statusOptions.filter(s => s.value !== "All").map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                        
                        {updatingStatusFor === ticket._id && (
                          <Loader2 className="w-3 h-3 text-[#C9A227] animate-spin" />
                        )}
                      </div>
                    </td>
                    <td className="px-5 py-4">
                      <div className="flex items-center gap-1.5">
                        <button 
                          onClick={() => handleViewDetails(ticket._id)}
                          title="View details" 
                          className="p-1.5 hover:bg-[#C9A227]/10 rounded transition-colors"
                        >
                          <Eye className="w-[15px] h-[15px] text-[#C9A227]" />
                        </button>
                        {canSendPaymentLink(ticket) && (
                          <button 
                            onClick={() => handleSendPaymentLink(ticket)}
                            disabled={sendingLinkFor === ticket._id}
                            title="Send payment link" 
                            className="p-1.5 hover:bg-blue-400/10 rounded transition-colors disabled:opacity-40"
                          >
                            {sendingLinkFor === ticket._id ? (
                              <Loader2 className="w-[15px] h-[15px] text-blue-400 animate-spin" />
                            ) : (
                              <Send className="w-[15px] h-[15px] text-blue-400" />
                            )}
                          </button>
                        )}
                        {/* <button
                          onClick={() => {
                            if (confirm(`Refresh ticket ${ticket.ticketId}?`)) {
                              fetchTickets();
                            }
                          }}
                          title="Refresh"
                          className="p-1.5 hover:bg-white/5 rounded transition-colors"
                        >
                          <RefreshCw className="w-[15px] h-[15px] text-white/30" />
                        </button> */}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default BRTTickets;